package library.setup;
public class InputDataError extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 503601285204482984L;

	/**
	 * Constructor for InputDataWarning
	 */
	public InputDataError(String message) {
		super(message);
	}

}

