package library.setup;

import java.sql.Connection;
import java.sql.SQLException;

import tools.Trace;

public class CreateTables extends ExecuteSQL {

	public CreateTables(Connection connection, 
					    String SQLFileName) {
		super(connection, SQLFileName);
	}
	
	/**
	 * @see ExecuteSQL#processSQLException(SQLException, String)
	 */
	protected void processSQLException(SQLException sql, String sqlString) {
		String sqlState = sql.getSQLState();
		if (sqlState.equals("42S01")) {
			Trace.display("SQL statement ");
			Trace.display(sqlString);
			Trace.display("The table being created already exists");
			Trace.display();
		} else {
			Trace.error("SQL: "+sqlString);
			Trace.error("Unexpected SQLException ");
			Trace.error("SQLSTATE: "+sqlState, sql);
		}
	}

}

