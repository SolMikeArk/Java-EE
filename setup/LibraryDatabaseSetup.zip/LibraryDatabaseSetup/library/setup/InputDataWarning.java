package library.setup;
public class InputDataWarning extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 468538327301594161L;

	/**
	 * Constructor for InputDataWarning
	 */
	public InputDataWarning(String message) {
		super(message);
	}

}

