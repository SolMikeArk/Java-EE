package library.setup;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import tools.ParseSQL;
import tools.Trace;

public abstract class ExecuteSQL {
	private String sqlFile;
	private InputStream inputStream;
	private Connection connection;
	
	/**
	 * Constructor for CreateTables
	 */
	public ExecuteSQL(Connection connection, 
					  String sqlFileName) {
		super();
		setInputStream(getClass().getClassLoader().getResourceAsStream(sqlFileName));
		setConnection(connection);
		setSQLFileName(sqlFileName);
	}

	/**
	 * Gets the SQL file name
	 * @return Returns a String
	 */
	@SuppressWarnings("unused")
	private String getSQLFileName() {
		return sqlFile;
	}
	/**
	 * Sets the SQL file name
	 * @param sqlFile The sqlFileName to set
	 */
	private void setSQLFileName(String sqlFile) {
		this.sqlFile = sqlFile;
	}

	public void run() {
		ParseSQL parser = new ParseSQL(new InputStreamReader(getInputStream()));
		
		String stmt = parser.getNext();					
		while (stmt != null) {
			execSQL(stmt);
			stmt = parser.getNext();
		}
		try {
			getConnection().commit();
		} catch (SQLException sql) {
			Trace.error("Could not commit create tables", sql);
		}
	}
	private void execSQL(String sqlString) {
		Connection connection = getConnection();
		try {
			Statement statement = connection.createStatement();
			statement.execute(sqlString);
			Trace.display("SQL Executed with no errors:");
		} catch (SQLException sql) {
			processSQLException(sql, sqlString);
		}
	}
	
	abstract protected void processSQLException(SQLException sql, String sqlString);

	/**
	 * Gets the connection
	 * @return Returns a Connection
	 */
	private Connection getConnection() {
		return connection;
	}
	/**
	 * Sets the connection
	 * @param connection The connection to set
	 */
	private void setConnection(Connection connection) {
		this.connection = connection;
	}
	/**
	 * Gets the inputStream
	 * @return Returns a InputStream
	 */
	private InputStream getInputStream() {
		return inputStream;
	}
	/**
	 * Sets the inputStream
	 * @param inputStream The inputStream to set
	 */
	private void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

}

