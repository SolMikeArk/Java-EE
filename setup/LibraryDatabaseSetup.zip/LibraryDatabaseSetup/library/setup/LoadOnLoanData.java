package library.setup;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import tools.ProcessData;
import tools.Trace;

public class LoadOnLoanData extends LoadData {
	private final static String SQL = "INSERT INTO LIBRARY.ONLOAN (PATRON_ID, ITEM_KEY, COPY_NUMBER, TIMES_RENEWED, DUE_DATE) VALUES(?, ?, ?, ? ,?)";
	private ProcessData process;

	/**
	 * Constructor for LoadCustomerData
	 */
	public LoadOnLoanData(Connection connection, String SQLFileName)
		throws IOException {
		super(connection, SQLFileName);
		process = new ProcessData();
	}

	/**
	 * @see LoadData#setFields(PreparedStatement, String)
	 */
	protected void setFields(String data)
		throws InputDataWarning, InputDataError {

		Integer custId;
		Integer itemId;
		Integer itemCopy;
		Integer timesRenewed;
		Date dueDate;

		// Give ProcessData the data to be loaded.
		process.setData(data);

		custId = process.getAsInteger(1, 4);
		itemId = process.getAsInteger(6, 9);
		itemCopy = process.getAsInteger(11, 12);
		timesRenewed = process.getAsInteger(14, 15);
		dueDate = process.getAsDate(17,23);

		try {
			setInteger(custId, 1);
			setInteger(itemId, 2);
			setInteger(itemCopy, 3);
			setInteger(timesRenewed, 4);
			setDate(dueDate, 5);

		} catch (SQLException sql) {
			setError(true);
			Trace.error(sql);
		}
	}

	/**
	 * @see LoadData#getSQLStatement()
	 */
	protected String getSQLStatement() {
		return SQL;
	}

}

