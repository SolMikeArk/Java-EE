package library.setup;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import tools.ProcessData;
import tools.Trace;

public class LoadItemData extends LoadData {
	private final static String SQL = "INSERT INTO LIBRARY.ITEM (ITEM_KEY, TYPE, ISBN_EQUIV, TITLE, AUTHOR, OVERSIZE, VOLUMES, PUBLISH_DATE) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
	private ProcessData process;

	/**
	 * Constructor for LoadCustomerData
	 */
	public LoadItemData(Connection connection, String SQLFileName)
		throws IOException {
		super(connection, SQLFileName);
		process = new ProcessData();
	}

	/**
	 * @see LoadData#setFields(PreparedStatement, String)
	 */
	protected void setFields(String data)
		throws InputDataWarning, InputDataError {
		Integer itemKey;
		String type;
		String isbnEquivalent;
		String title;
		String author;
		String oversize;
		Integer volumes;
		Date publishDate;
				
		// Give ProcessData the data to be loaded.
		process.setData(data);

		itemKey = process.getAsInteger(1, 4);
		type = process.getAsString(6, 6);
		isbnEquivalent = process.getAsString(8, 17);
		title = process.getAsString(19, 69);
		author = process.getAsString(71, 94);
		oversize = process.getAsString(96, 96);
		volumes = process.getAsInteger(98, 103);
		publishDate = process.getAsDate(105, 120);
			
		try {
			setInteger(itemKey, 1);
			setChar(type, 2);
			setVarchar(isbnEquivalent, 3);
			setVarchar(title, 4);
			setVarchar(author, 5);
			setChar(oversize, 6);
			setInteger(volumes, 7);
			setDate(publishDate, 8);
		} catch (SQLException sql) {
			setError(true);
			Trace.error(sql);
		}
	}

	/**
	 * @see LoadData#getSQLStatement()
	 */
	protected String getSQLStatement() {
		return SQL;
	}

}

