package library.setup;

import java.io.IOException;
import java.sql.Connection;

import tools.ProcessData;

/**
 * @author USERID
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class LoadTableMaxData extends LoadData {
	
	private final static String statement = "INSERT INTO LIBRARY.TABLEMAX (TABLE_ID, KEY_ID, MAXIMUM) SELECT ";
	@SuppressWarnings("unused")
	private final static String group_by  = "GROUP BY";
	private ProcessData process;
	private String constructed_statement = "SELECT * FROM LIBRARY.TABLEMAX";

	/**
	 * Constructor for LoadTableMaxData.
	 * @param connection
	 * @param sqlFileName
	 * @throws IOException
	 */
	public LoadTableMaxData(Connection connection, String sqlFileName)
		throws IOException {
		super(connection, sqlFileName);
		process = new ProcessData();
	}

	/**
	 * @see library.setup.LoadData#getSQLStatement()
	 */
	protected String getSQLStatement() {
		return constructed_statement;
	}

	/**
	 * @see library.setup.LoadData#setFields(String)
	 */
	protected void setFields(String data)
		throws InputDataWarning, InputDataError {
			
			process.setData(data);
			
			Integer table_id   = process.getAsInteger(1,2);
			String  table_name = process.getAsString(4,9).trim();
			String  key_field  = process.getAsString(11,18).trim();
			String  max_field  = process.getAsString(20,30).trim();
			
			constructed_statement = statement + table_id + ", " + key_field + ", " + "max(" + max_field + ") from library." + table_name ;
			
			if (key_field.compareToIgnoreCase("0") != 0)
			  constructed_statement += " GROUP BY " + key_field;
			  
			prepareSQL();
	    			
	}

}
