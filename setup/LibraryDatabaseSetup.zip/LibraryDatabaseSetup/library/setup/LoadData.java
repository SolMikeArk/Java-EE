package library.setup;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

import tools.Trace;

public abstract class LoadData {
	private String fileName;
	private Connection connection;
	private BufferedReader bufferedReader;
	private PreparedStatement statement;
	@SuppressWarnings("unused")
	private String SQLStatement;
	private boolean warning;
	private boolean error;
	private boolean dynamic_statement;
	
	public LoadData(Connection connection, String sqlFileName) throws IOException {
		super();
		setConnection(connection);
		setFileName(sqlFileName);
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream(sqlFileName);
		InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
		BufferedReader reader = new BufferedReader(inputStreamReader);
		setBufferedReader(reader);
		setDynamic_statement(false);
	}

	public void run() {
		BufferedReader in = getBufferedReader();

		prepareSQL();
		
		// read in the data and load it into the table		
		int total = 0;
		int totalOK = 0;
		int totalWarnings = 0;
		int totalErrors = 0;
		String data = null;
		
		try {
			while (in.ready()) {
				setWarning(false);
				setError(false);
				data = in.readLine();				
				total++;
				try {
					setFields(data);
					execSQL();
					totalOK++;
				} catch (InputDataWarning warn) {
					setWarning(true);
					Trace.error(warn);
				} catch (InputDataError err) {
					setError(true);
					Trace.error(err);
				} catch (SQLException sql) {
					processSQLException(sql);
				}
				if (isWarning()) {
					totalWarnings++;
				}
				if (isError()) {
					totalErrors++;
				}
			}
			getConnection().commit();
			
			Trace.display("A total of "+total+" records were processed");
			Trace.display("There were "+totalOK+" rows added without errors");
			Trace.display("There were "+totalWarnings+" warnings and "+totalErrors+" errors");
		} catch (IOException io) {
			Trace.error("Unexpected IO error reading in data from file "+getFileName(), io);
		} catch (SQLException sql) {
			Trace.error("Unable to commit rows", sql);
		}
	}

	protected void prepareSQL() {
		// first set up the SQL command
		Connection connection = getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(getSQLStatement());
			setStatement(statement);
		} catch (SQLException sqlException) {
			processSQLException(sqlException);
			Trace.error("No data was imported from this file");
			return;
		}
	}
	
	protected void execSQL() throws SQLException {
		@SuppressWarnings("unused")
		Connection connection = getConnection();
		getStatement().execute();
		Trace.message("SQL Executed with no errors", Trace.HIGH);
	}
	
	protected void processSQLException(SQLException sql) {
		String sqlState = sql.getSQLState();
		
		if (sqlState.startsWith("01")) {
			// warning
			setWarning(true);
			Trace.display(sql.getMessage());
		} else {
			// error
			setError(true);
			Trace.display(sql.getMessage());
		}
	}

	/**
	 * Gets the connection
	 * @return Returns a Connection
	 */
	private Connection getConnection() {
		return connection;
	}
	
	/**
	 * Sets the connection
	 * @param connection The connection to set
	 */
	private void setConnection(Connection connection) {
		this.connection = connection;
	}
	
	/**
	 * Gets the bufferedReader
	 * @return Returns a BufferedReader
	 */
	private BufferedReader getBufferedReader() {
		return bufferedReader;
	}
	
	/**
	 * Sets the bufferedReader
	 * @param bufferedReader The bufferedReader to set
	 */
	private void setBufferedReader(BufferedReader bufferedReader) {
		this.bufferedReader = bufferedReader;
	}
	
	/**
	 * Gets the SQL file name
	 * @return Returns a String
	 */
	private String getFileName() {
		return fileName;
	}
	/**
	 * Sets the SQL file name
	 * @param sqlFile The sqlFileName to set
	 */
	private void setFileName(String sqlFile) {
		fileName = sqlFile;
	}
	/**
	 * Gets the statement
	 * @return Returns a Statement
	 */
	private PreparedStatement getStatement() {
		return statement;
	}
	/**
	 * Sets the statement
	 * @param statement The statement to set
	 */
	private void setStatement(PreparedStatement statement) {
		this.statement = statement;
	}

	/**
	 * Gets the warning
	 * @return Returns a boolean
	 */
	private boolean isWarning() {
		return warning;
	}

	/**
	 * Sets the warning
	 * @param warning The warning to set
	 */
	protected void setWarning(boolean warning) {
		this.warning = warning;
	}

	/**
	 * Gets the error
	 * @return Returns a boolean
	 */
	private boolean isError() {
		return error;
	}

	/**
	 * Sets the error
	 * @param error The error to set
	 */
	protected void setError(boolean error) {
		this.error = error;
	}
	
	protected void setInteger(Integer field, int column) throws SQLException {
		PreparedStatement statement = getStatement();
		if (field == null) {
			statement.setNull(column, Types.INTEGER);
		} else {
			statement.setInt(column, field.intValue());
		}
	}
	
	protected void setVarchar(String field, int column) throws SQLException {
		PreparedStatement statement = getStatement();
		if (field == null) {
			statement.setNull(column, Types.VARCHAR);
		} else {
			statement.setString(column, field);
		}
	}
	
	protected void setChar(String field, int column) throws SQLException {
		PreparedStatement statement = getStatement();
		if (field == null) {
			statement.setNull(column, Types.CHAR);
		} else {
			statement.setString(column, field);
		}
	}

	protected void setDate(Date field, int column) throws SQLException {
		PreparedStatement statement = getStatement();
		if (field == null) {
			statement.setNull(column, Types.DATE);
		} else {
			statement.setDate(column, field);
		}
	}
	/**
	 * Gets the sQLStatement
	 * @return Returns a String
	 */
	protected abstract String getSQLStatement();

	/**
	 * Sets the fields for the SQL statement
	 * @param statement. The statement to be set
	 * @param data. input data to be used in setting the fields
	 * @exception InputDataWarning. There is a warning associated with the data
	 * @exception InputDataError. There was an error processing the data
	 */	
	protected abstract void setFields(String data) throws InputDataWarning, InputDataError;
	/**
	 * Returns the dynamic_statement.
	 * @return boolean
	 */
	public boolean isDynamic_statement() {
		return dynamic_statement;
	}

	/**
	 * Sets the dynamic_statement.
	 * @param dynamic_statement The dynamic_statement to set
	 */
	public void setDynamic_statement(boolean dynamic_statement) {
		this.dynamic_statement = dynamic_statement;
	}

}