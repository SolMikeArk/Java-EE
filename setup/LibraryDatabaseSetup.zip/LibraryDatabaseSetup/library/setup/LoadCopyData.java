package library.setup;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import tools.ProcessData;
import tools.Trace;

public class LoadCopyData extends LoadData {
	private final static String SQL = "INSERT INTO LIBRARY.COPY (ITEM_KEY, COPY_NUMBER, LOANABLE) VALUES(?, ?, ?)";
	private ProcessData process;

	/**
	 * Constructor for LoadCustomerData
	 */
	public LoadCopyData(Connection connection, String SQLFileName)
		throws IOException {
		super(connection, SQLFileName);
		process = new ProcessData();
	}

	/**
	 * @see LoadData#setFields(PreparedStatement, String)
	 */
	protected void setFields(String data)
		throws InputDataWarning, InputDataError {
		Integer itemKey;
		Integer copyNumber;
		String loanable;
		// Give ProcessData the data to be loaded.
		process.setData(data);

		itemKey = process.getAsInteger(1, 4);
		copyNumber = process.getAsInteger(6, 7);
		loanable = process.getAsString(9, 9);
		
		try {
			setInteger(itemKey, 1);
			setInteger(copyNumber, 2);
			setChar(loanable, 3);
		} catch (SQLException sql) {
			setError(true);
			Trace.error(sql);
		}
	}

	/**
	 * @see LoadData#getSQLStatement()
	 */
	protected String getSQLStatement() {
		return SQL;
	}

}

