package library.setup;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import tools.ProcessData;
import tools.Trace;

public class LoadPatronData extends LoadData {
	private final static String SQL = "INSERT INTO LIBRARY.PATRON (PATRON_ID, FIRST_NAME, LAST_NAME, PASSWORD, EMAIL) VALUES(?, ?, ?, ?, ?)";
	private ProcessData process;

	/**
	 * Constructor for LoadCustomerData
	 */
	public LoadPatronData(Connection connection, String SQLFileName)
		throws IOException {
		super(connection, SQLFileName);
		process = new ProcessData();
	}

	/**
	 * @see LoadData#setFields(PreparedStatement, String)
	 */
	protected void setFields(String data)
		throws InputDataWarning, InputDataError {
		Integer patronId;
		String firstName;
		String lastName;
		String password;
		String eMail;
		// Give ProcessData the data to be loaded.
		process.setData(data);
		patronId = process.getAsInteger(1, 4);
		firstName = process.getAsString(6, 14);
		lastName = process.getAsString(16, 39);
		password = process.getAsString(41, 51);
		eMail = process.getAsString(53, 90);
		try {
			setInteger(patronId, 1);
			setVarchar(firstName, 2);
			setVarchar(lastName, 3);
			setVarchar(password, 4);
			setVarchar(eMail, 5);			
		} catch (SQLException sql) {
			setError(true);
			Trace.error(sql);
		}
	}

	/**
	 * @see LoadData#getSQLStatement()
	 */
	protected String getSQLStatement() {
		return SQL;
	}

}

