package library.setup;

import java.sql.Connection;
import java.sql.SQLException;

import tools.Trace;

public class DropTables extends ExecuteSQL {
	/**
	 * Constructor for DropTables
	 */
	public DropTables(Connection connection, String SQLFileName) {
		super(connection, SQLFileName);
	}

	/**
	 * @see ExecuteSQL#processSQLException(SQLException, String)
	 */
	protected void processSQLException(SQLException sql, String sqlString) {
		String sqlState = sql.getSQLState();
		if (sqlState.equals("42Y55") ||			// table does not exist
				sqlState.equals("42000")||		// syntax error or acces rule violation
			    sqlState.equals("42Y07")   ) {  //schema does not exist
			// the table doesn't exist
		} else {
			Trace.error("SQL: "+sqlString);
			Trace.error("Unexpected SQLException ");
			Trace.error("SQLSTATE: "+sqlState, sql);
		}
	}
}

