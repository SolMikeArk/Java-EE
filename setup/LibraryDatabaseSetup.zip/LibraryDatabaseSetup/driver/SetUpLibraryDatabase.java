package driver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import library.setup.CreateTables;
import library.setup.DropTables;
import library.setup.LoadCopyData;
import library.setup.LoadItemData;
import library.setup.LoadOnLoanData;
import library.setup.LoadPatronData;
import library.setup.LoadTableMaxData;
import tools.DriverNotFound;
import tools.Trace;
import database.DatabaseManagement;

/**
 * @author vogeld
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class SetUpLibraryDatabase {
	private final static String DROP = "drop.txt";
	private final static String CREATE = "tables.txt";
	private final static String PATRON = "patrons.txt";
	private final static String ITEM = "items.txt";
	private final static String COPY = "copies.txt";
	private final static String ONLOAN = "onloan.txt";
	private final static String TABLEMAX = "tablemax.txt";

	public static void main(String[] args) {
		Connection connection = null;
		try {
			connection = DatabaseManagement.getConnection();

			// first drop the existing tables
			Trace.display("Drop existing tables (if they exist)");
			DropTables drop = new DropTables(connection, DROP);
			drop.run();

			// now create the new tables
			Trace.display();
			Trace.display("Create the library tables");
			CreateTables create = new CreateTables(connection, CREATE);
			create.run();

			// now load the PATRON table
			Trace.display();
			Trace.display("Load the patron table");
			try {
				LoadPatronData data = new LoadPatronData(connection, PATRON);
				data.run();
			} catch (IOException io) {
				Trace.error("Error loading patron table", io);
			}

			// now load the ITEM table
			Trace.display();
			Trace.display("Load the item table");
			try {
				LoadItemData data = new LoadItemData(connection, ITEM);
				data.run();
			} catch (IOException io) {
				Trace.error("Error loading item table", io);
			}

			// now load the COPY table
			Trace.display();
			Trace.display("Load the copy table");
			try {
				LoadCopyData data = new LoadCopyData(connection, COPY);
				data.run();
			} catch (IOException io) {
				Trace.error("Error loading copy table", io);
			}

			// now load the ONLOAN table
			Trace.display();
			Trace.display("Load the onloan table");
			try {
				LoadOnLoanData data = new LoadOnLoanData(connection, ONLOAN);
				data.run();
			} catch (IOException io) {
				Trace.error("Error loading onloan table", io);
			}
			// finally load the TABLEMAX table
			Trace.display();
			Trace.display("Load the tablemax table");
			try {
				LoadTableMaxData data =
					new LoadTableMaxData(connection, TABLEMAX);
				data.run();
			} catch (IOException io) {
				Trace.error("Error loading tablemax table", io);
			}
			Trace.display();
		} catch (DriverNotFound dnf) {
			Trace.error(dnf);
			Trace.error("Make sure the driver is correct");
			Trace.error(
				"Make sure the driver jar is the Java Build Path for this project");
			Trace.error(
				"Make sure the driver jar is in the Classpath for this project");
		} catch (SQLException sql) {
			processSQLException(sql);
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException sql) {
				}
			}
		}
	}

	/**
	 * Analyze SQLException and creates appropriate message
	 * @param sql
	 */
	private static void processSQLException(SQLException sql) {

		String state = sql.getSQLState();
		if (state != null) {
			if (state.equals("08004")) {
				Trace.error("The userid or password are not correct");
			} else if (state.equals("08001")) {
				Trace.error("The database does not exist");
				Trace.error("Be sure the database name is correct");
				Trace.error("Be sure the database exists");
			} else if (sql.getMessage().equals("No suitable driver")) {
				Trace.error("The URL syntax may be in error");
			} else {
				Trace.error("Could not get a connection", sql);
			}
		} else {
			// nulls are valid in JDBC for sqlstate and msg
			String msg = sql.getMessage();
			if (msg == null) {
				Trace.error("Could not get a connection");
			} else {
				Trace.error(msg);
			}
		}
	}
}
