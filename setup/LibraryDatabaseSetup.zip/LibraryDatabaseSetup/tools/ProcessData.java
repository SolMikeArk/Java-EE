package tools;

import java.sql.Date;

public class ProcessData {
	private static final String NULL = "<null>";
	private String currentData;	
	private long today;
	private long oneDay = 1000*60*60*24;

	/**
	 * Constructor for ProcessData. 
	 * This class is used to pull in data from columns of
	 * a string. 
	 * 
	 * The string <null> in the columns indicates that 
	 * no value is to be returned (null).
	 * 
	 * For Dates the values are numbers. The number indicates
	 * the number of days from today to be used for the date.
	 * Example: A date value of -2 says the date is two days ago.
	 * A value of 14 would be two weeks from today.
	 */
	public ProcessData() {
		super();
		today = new java.util.Date().getTime();
	}
	
	/**
	 * Gets a value as a String
	 * @param start The beginning column (1 based)
	 * @param end The ending column (1 based, inclusive)
	 * @return Returns the contents of the columns as a String
	 */
	public String getAsString(int start, int end) {
		String result = getRawField(start, end);

		// if the data was missing or has the value specified
		//  by NULL the data is considered missing (and will be
		//  set to null
		if (result == null || result.trim().equals(NULL)) {
			result = null;
		} else {
			result = trimTrailing(result);
		}
		
		return result;
	}

	/**
	 * Gets a value as an Integer
	 * @param start The beginning column (1 based)
	 * @param end The ending column (1 based, inclusive)
	 * @return Returns the contents of the columns as an integer
	 */
	public Integer getAsInteger(int start, int end) {
		Integer result = null;
		String rawData = getAsString(start, end);
		
		if (rawData == null) {
			result = null;
		} else {
			try {
				// convert to a number
				result = new Integer(rawData.replace('+',' ').trim());
			} catch (NumberFormatException e) {
				// if invalid, set to null
				result = null;
				Trace.message("Invalid number field with value "+rawData, Trace.HIGH);
			}
		}
		
		return result;	
	}
	
	public Date getAsDate(int start, int end) {
		Date result = null;
		Integer rawValue = getAsInteger(start, end);
		long value;
		
		if (rawValue == null) {
			result = null;
		} else {
			value = rawValue.longValue();
			result = new Date(today+(value*oneDay));
		}

		return result;
	}
	
	private String getRawField(int start, int end) {
		String result = null;
		String data = getData();
		int dataLength = data.length();

		if (start < 1) {
			start = 1;
			Trace.message("Start column is < 0", Trace.HIGH);
		}

		if (start > end) {
			int temp = start;
			start = end;
			end = temp;
			Trace.message("Start and end columns were swapped", Trace.HIGH);
		}
		
		if (dataLength < start) {
			result = null;
			Trace.message("Start column not within data size", Trace.HIGH);
		} else if (end >= dataLength) {
			result = data.substring(start-1);
		} else {
			result = data.substring(start-1, end);
		} 
		
		return result;
	}
	
	/**
	 * Gets the currentData
	 * @return Returns a String
	 */
	private String getData() {
		return currentData;
	}
	
	/**
	 * Sets the current data
	 * @param current data The current data to set
	 */
	public void setData(String currentData) {
		this.currentData = currentData;
	}
	
	private String trimTrailing(String value) {
		String result = null;
		
		if (value == null) {
			result = null;
		} else {
			
			int last = value.length() - 1;
			
			while (last >= 0 && value.charAt(last) == ' ') {
				last--;
			}
//			if (last >= 0) {
				result = value.substring(0, last+1);
//			} else {
//				result = "";
//			}
		}
		
		return result;
	}
}

