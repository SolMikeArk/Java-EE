package tools;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class ParseSQL {
	private BufferedReader bufferedReader = null;
	private static String COMMENT = "--";
	private static String END_DELIM = ";";
	private boolean eof = false;
	
	public ParseSQL(String  fileName) throws IOException {
		this(new FileReader(fileName));
	}
	
	public ParseSQL(Reader reader) {
		super();
		setBufferedReader(new BufferedReader(reader));
	}
	public String getNext() {
		BufferedReader in = getBufferedReader();
		
		StringBuffer nextStatement = new StringBuffer(1000);
		
		if (eof) {
			return null;
		}
		
		try {
			String line = null;
			boolean eos = false;
			
			while (in.ready()) {
				line = in.readLine();
				
				// check for null;
				if (line == null) {
					eos = true;
					continue;
				}
				
				// check for comments
				if (line.startsWith(COMMENT)) {
					// ignore comments
					continue;
				}
				
				if (line.length() == 0) {
					// ignore blank lines
					continue;
				}
				
				if (line.endsWith(END_DELIM)) {
					// the end of the SQL statement
					line = line.substring(0, line.length()-1);
					eos = true;
				}
				
				nextStatement.append(line);
				nextStatement.append(' ');
				
				if (eos) {
					// end of the SQL statement
					return new String(nextStatement).trim();
				}
			}
			
			try {
				in.close();
				eof = true;			
			} catch (IOException closeException){
			}
			return null;
		} catch (IOException io) {
			Trace.error("Unexpected exception parsing SQL in ParseSQL.getNext()", io);
			return null;
		}
	}
	
	/**
	 * Gets the bufferedReader
	 * @return Returns a BufferedReader
	 */
	private BufferedReader getBufferedReader() {
		return bufferedReader;
	}
	/**
	 * Sets the bufferedReader
	 * @param bufferedReader The bufferedReader to set
	 */
	private void setBufferedReader(BufferedReader bufferedReader) {
		this.bufferedReader = bufferedReader;
	}

}

