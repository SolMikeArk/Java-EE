package tools;
public class SyntaxException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8069593611940208129L;

	/**
	 * Constructor for SyntaxException
	 */
	public SyntaxException(String message) {
		super(message);
	}
}

