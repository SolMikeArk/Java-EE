Run the following command to drop any old tables and load sample data into the tables.

java -cp "%CLASSPATH%;SetupDatabase.jar" driver.SetUpLibraryDatabase

for the above command the work the database must already exist.

The following command will just drop the tables.

java -cp "%CLASSPATH%;SetupDatabase.jar" driver.DropLibraryTables

the above command does not delete the database.

Note the code is in a jar file, but the input files are in external files.  

This was done to allow you a way of changing the create table statements and to allow you to import your own data.

In the sql files drop.txt and tables.txt the SQL statements must end with ";".  Comments begine with "--" in columns 1 and 2.

The code (packages) are exported in a jar and the text files are exported to the file system.

The file "databaseInformation.properties" contains the names of the database driver, URL, user id and password to be used to create and populate the tables.