package tests;

import java.sql.Date;

import tools.ProcessData;
import tools.Trace;

public class TestProcessData {

	public static void main(String[] args) {
		// Trace.setTraceLevel(Trace.HIGH);
		String data = null;
		Date date1;
		Date date2;
		Date date3;
		Integer int1;
		Integer int2;
		@SuppressWarnings("unused")
		Integer int3;
		String text1;
		String text2;
		String text3;
		
		ProcessData process = new ProcessData();
		//      000000000111111111122222
		//      123456789012345678901234
		data = "123 abc  <null>  0 -1 +3";
		process.setData(data);
		Trace.display(data);
		Trace.display();
		int1  = process.getAsInteger(1, 3);  // 123
		text1 = process.getAsString(5, 9);   // abc
		text2 = process.getAsString(10, 17); // null
		date1 = process.getAsDate(18, 19);   // today
		date2 = process.getAsDate(20, 21);   // yesterday
		date3 = process.getAsDate(23, 25);   // 3 days from now
		Trace.display("123 \"abc\" null today yesterday, 3 days from now");
		Trace.display(int1.toString());
		Trace.display("\""+text1+"\"");
		Trace.display(text2);
		Trace.display(date1.toString());
		Trace.display(date2.toString());
		Trace.display(date3.toString());
		Trace.display();
		Trace.display();
		
		//      00000000011111111112222222222333333333344
		//      12345678901234567890123456789012345678901
		data = " 123    abc      <null>     <null> <null>";
		process.setData(data);
		Trace.display(data);
		Trace.display();
		int1  = process.getAsInteger(1, 8);  // 123
		text1 = process.getAsString(6, 8);   // ""
		text2 = process.getAsString(-2, 16); // "123    abc"
		text3 = process.getAsString(18, 26); // <null>		
		int2 = process.getAsInteger(29, 34); // <null>
		date1 = process.getAsDate(36, 100);  // <null>

		Trace.display("123 \"\" \" 123    abc\" null null null");
		Trace.display(int1.toString()); 
		Trace.display("\""+text1+"\"");
		Trace.display("\""+text2+"\"");
		System.out.println(text3);
		System.out.println(int2);
		System.out.println(date1);
	}
}

