package tests;

import java.util.StringTokenizer;

public class StringTokenizerTest {
	@SuppressWarnings("unused")
	private String statement;
	private StringTokenizer tokenizer;
	/**
	 * Constructor for StringTokenizerTest
	 */
	public StringTokenizerTest() {
		super();
	}

	public static void main(String[] args) {
		StringTokenizerTest test = new StringTokenizerTest();

		test.setStatement("(1,22,integer)(30,40,string)(61,70,date)");
		test.parse();
		test.setStatement(" ( 1 , 22 , integer )   ( 30 ,  40   ,   string)   ( 61  ,70   ,    date)   ");
		test.parse();
	}
	
	private void setStatement(String stmt) {
		statement = stmt;
		tokenizer = new StringTokenizer(stmt,"(,)",true);
	}
	
	private void parse() {
		String token = null;
		while (tokenizer.hasMoreElements()) {
			token = tokenizer.nextToken();
			printToken(token);
		}		
	}
	
	private void printToken(String token) {
		System.out.println("Token '"+token+"', size="+token.length());
	}
}

