package database;

import java.sql.Connection;
import java.sql.SQLException;

public class ConnectionFactory {

	private BuildConnection delegate;

	/**
	 * Constructor for ConnectionFactory 
	 */
	public ConnectionFactory(
		String aDriver,
		String aUrl,
		String aUserid,
		String aPassword)
		throws ClassNotFoundException {
		super();
		delegate =
			new DriverManagerConnection(aDriver, aUrl, aUserid, aPassword);
	}

	/**
	 * Constructor for ConnectionFactory (type = ds)
	 * Currently this only creates a Derby EmbeddedConnectionPoolDataSource
	 */
	public ConnectionFactory(
		String aDatabase,
		String aUserid,
		String aPassword) {
		super();
		delegate = new DataSourceConnection(aDatabase, aUserid, aPassword);
	}

	/**
	 * Gets the connection associated with delegate
	 * @return Connection
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException {
		Connection connection = delegate.getConnection();
		connection.setAutoCommit(false);
		return connection;
	}

}
