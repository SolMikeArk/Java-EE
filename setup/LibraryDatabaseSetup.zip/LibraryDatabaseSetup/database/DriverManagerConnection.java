package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

/**
 * @author vogeld
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class DriverManagerConnection implements BuildConnection {
	static private Set<String> set = new HashSet<String>();
	private String driver;
	private String url;
	private String userid;
	private String password;
		
	/**
	 * Create the DriverManagerConnection
	 * @param newDriver Driver to be loaded and used to aquire a DriverManager
	 * @param newUrl URL used get the Connection
	 * @param newUserid Userid used to get the Connection
	 * @param newPassword Password used to get the Connection
	 */
	public DriverManagerConnection(String newDriver, String newUrl, String newUserid, String newPassword) throws ClassNotFoundException {
		// save the input parameters
		driver = newDriver;
		url = newUrl;
		userid = newUserid;
		password = newPassword;
		
		// load the driver
		loadDriver();
	}
		
	/**
	 * Load the driver (if it hasn't already been loaded.
	 * @exception ClassNotFoundException the Driver could not be loaded
	 */
	private void loadDriver() throws ClassNotFoundException {
		if (!set.contains(driver)) {
			Class.forName(driver); // load the driver
			set.add(driver);	   // add it to the collection	
		}
	}

	/**
	 * Get a Connection from the DriverManager
	 * @exception SQLException SQL error getting the connection
	 * @see database.BuildConnection#getConnection()
	 **/
	
	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, userid, password);
	}		
}
