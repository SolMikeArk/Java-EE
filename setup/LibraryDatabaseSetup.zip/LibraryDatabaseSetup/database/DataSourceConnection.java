/*
 * Created on Sep 20, 2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package database;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.derby.jdbc.EmbeddedConnectionPoolDataSource;

/**
 * Currently this only creates a Derby EmbeddedConnectionPoolDataSource
 */

public class DataSourceConnection implements BuildConnection{
	
	private String database;
	@SuppressWarnings("unused")
	private String userid;
	@SuppressWarnings("unused")
	private String password;
	@SuppressWarnings("unused")
	private static final String host = "localhost";

	private EmbeddedConnectionPoolDataSource dataSource;
	
	/**
	 *  Constructor for DataSourceConnection
	 * @param aDatabase
	 * @param aUserid
	 * @param aPassword
	 * 
	 */
	public DataSourceConnection(String aDatabase, String aUserid, String aPassword) {
		super();
		database = aDatabase;
		userid = aUserid;
		password = aPassword;
		create();	 
	}
	
	/**
	 * Creates a Derby Data source
	 */
	private void create() {
		dataSource = new EmbeddedConnectionPoolDataSource();
		dataSource.setDatabaseName(database);

	}
	
	
	/* *
	 * Gets the connection association with the data source
	 *  @return connection 
	 *  @see database.BuildConnection#getConnection()
	 */
	public Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}	

}
