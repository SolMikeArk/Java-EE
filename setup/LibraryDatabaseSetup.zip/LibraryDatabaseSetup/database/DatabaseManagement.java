package database;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import tools.DriverNotFound;
import tools.Trace;

/**
 * @author 
 * *
 * Processes properties file to determine database management parameters.
 * There are two different ways to specifiy the properties file: type=ds
 * and type=jdbc. If a type is not specified, it defaults to jdbc.
 * 
 * Type=jdbc says to use the jdbc driver manager to connect to the data source.
 * The parameters to be spcified include:
 * 
 * type=jdbc
 * userid=<database connection userid> (default: userid)
 * password=<database connection password> (default: password)
 * url=<jdbc url of the database> (default: jdbc:derby:C:\\Labs\\RD810\\database\\library)
 * driver=<name of the jdbc driver> (default: org.apache.derby.jdbc.EmbeddedDriver)
 * The default driver is the embedded derby driver located derby.jar.
 * 
 * Type=ds says to use a derby simple data source interface to connect to the data source  
 * The parameters to be specified include:
 * type=ds
 * userid=<database connection userid> (default: userid)
 * password=<database connection password> (default: password)
 * database=<derby database name> (default: C:\\Labs\\RD810\\database\\library;create=true)
 * 
 * 
 */
public class DatabaseManagement {
	//	resource bundle keys
	private static final String TYPE_JDBC = "jdbc";
	private static final String TYPE_DS = "ds";
	private static final String TYPE = "type";
	private static final String USERID = "userid";
	private static final String PASSWORD = "password";
	private static final String DRIVER = "driver";
	private static final String URL = "url";
	private static final String DATABASE = "database";

	// default values to use if no properties bundle (or property name) is found
	private static String type = TYPE_JDBC;
	private static String userid = "userid";
	private static String password = "password";
	private static String driver = "org.apache.derby.jdbc.EmbeddedDriver";
	private static String url = "jdbc:derby:/root/labfiles/wd026/database/library;create=true";
	
	//for datasource TYPE_DS
	private static String database = "/root/labfiles/wd026/database/library;create=true"; 

	private static final String file = "databaseInformation.properties";

	static {
		refresh();
	}

	/**
	 * Reads properties file to determine parameters specified
	 * for type = jdbc or type = pool
	 */
	public static void refresh() {
		try {
			InputStream inputStream =
				DatabaseManagement.class.getClassLoader().getResourceAsStream(
					file);
			if (inputStream != null) { // properties bundle file is available
				Properties properties = new Properties();
				properties.load(inputStream);
				type = properties.getProperty(TYPE, type);
				if (type.equalsIgnoreCase(TYPE_JDBC)) {
					userid = properties.getProperty(USERID, userid);
					password = properties.getProperty(PASSWORD, password);
					driver = properties.getProperty(DRIVER, driver);
					url = properties.getProperty(URL, url);
				}
				if (type.equalsIgnoreCase(TYPE_DS)) {
					userid = properties.getProperty(USERID, userid);
					password = properties.getProperty(PASSWORD, password);
					database = properties.getProperty(DATABASE, database);
				}
			} else {
				processBundleError(file);
			}
		} catch (IOException ioe) {
			processBundleError(file);
		}
	}

	/**
	 * Handles missing properties bundle (use defaults).
	 * @param fileName
	 */
	private static void processBundleError(String fileName) {
		Trace.error("Resource bundle \"" + fileName + "\" not found");
		Trace.error("Default values for database access will be used");
	}

	/**
	 * * Gets the connection associated with parameters
	 * specified in the properties file through the ConnectionFactory
	 * @return Connection
	 * @throws SQLException
	 * @throws DriverNotFound
	 */
	public static Connection getConnection()
		throws SQLException, DriverNotFound {
		ConnectionFactory factory = null;
		try {
			if (type.equalsIgnoreCase(TYPE_JDBC)) {
				factory = new ConnectionFactory(driver, url, userid, password);
			} else { //TYPE_DS
				factory = new ConnectionFactory(database, userid, password);
			}
		} catch (ClassNotFoundException e) {
			throw new DriverNotFound(driver);
		}
		return factory.getConnection();
	}

}