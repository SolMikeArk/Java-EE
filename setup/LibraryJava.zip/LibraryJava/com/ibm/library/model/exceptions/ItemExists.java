package com.ibm.library.model.exceptions;
public class ItemExists extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4615047882988782454L;

	/**
	 * Constructor for ItemExists
	 */
	public ItemExists(int id) {
		super("Item "+id+" already exists");
	}
	
	/**
	 * Constructor for ItemExists
	 */
	public ItemExists(String title) {
		super("Item with title \""+title+"\" already exists");
	}
}

