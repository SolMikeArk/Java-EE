package com.ibm.library.model.exceptions;
public class CopyExists extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor for PatronExists
	 */
	public CopyExists(int id) {
		super("Patron "+id+" already exists");
	}
	
	/**
	 * Constructor for PatronExists
	 */
	public CopyExists(String email) {
		super("Patron "+email+" already exists");
	}

}

