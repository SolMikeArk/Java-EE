package com.ibm.library.model.exceptions;
public class CopyNotFound extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3354224831086987116L;

	/**
	 * Constructor for PatronExists
	 */
	public CopyNotFound(int itemId, int copyNumber) {
		super("Copy "+copyNumber+" of item "+itemId+"  was not found");
	}
}

