package com.ibm.library.model.exceptions;

/**
 * @author vogeld
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class InvalidPassword extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5235456182563700991L;

	/**
	 * Constructor for InvalidPassword.
	 * @param arg0
	 */
	public InvalidPassword(String message) {
		super(message);
	}

}
