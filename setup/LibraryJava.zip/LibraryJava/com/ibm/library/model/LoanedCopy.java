package com.ibm.library.model;

import java.io.Serializable;
import java.util.Date;

import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.exceptions.CopyNotFound;
import com.ibm.library.model.exceptions.RenewFailed;

/**
 * @author vogeld
 *
 */
public class LoanedCopy implements Serializable {
	private static final long serialVersionUID = 859693275339941050L;
	
	private String title;
	private String author;
	private int itemId;
	private int copyNumber;
	private Date due;
	private int timesRenewed;
	private boolean renewRequested;
	private boolean renewAccomplished;
	private String renewMessage;

	public LoanedCopy() {
		this(0, 0, "", "", new Date(), 0);
	}
	/**
	 * Constructor for LoanedCopy.
	 */
	public LoanedCopy(int itemId, int copyNumber, String title, String author, Date due, int timesRenewed) {
		super();
		setItemId(itemId);
		setCopyNumber(copyNumber);
		setTitle(title);
		setAuthor(author);
		setDue(due);
		setTimesRenewed(timesRenewed);
		setRenewRequested(false);
		setRenewAccomplished(false);
		setRenewMessage("");
	}

	/**
	 * Try to renew the loaned copy
	 */
	public void renew() throws SystemUnavailableException, CopyNotFound {
		if (isRenewRequested()) {
			// create a Copy object and let it do the renew
			Copy copy = createCopy();
			try {
				// try the renew
				copy.renew();
				// it was renewed, update the LoanedCopy object
				setRenewAccomplished(true);
				setDue(copy.getDue());
				setTimesRenewed(copy.getTimesRenewed());
			} catch (RenewFailed e) {
				// the renew failed
				setRenewAccomplished(false);
				setRenewMessage(e.getMessage());
			}			
		}
	}

	/**
	 * Method createCopy.
	 * @return Copy
	 */
	private Copy createCopy() {
		Copy copy = null;
		copy = new Copy(getItemId(), getCopyNumber(), true, getDue(), getTimesRenewed());
		return copy;
	}
	

	/**
	 * Returns the renewAccomplished.
	 * @return boolean
	 */
	public boolean isRenewAccomplished() {
		return renewAccomplished;
	}

	/**
	 * Returns the renewMessage.
	 * @return String
	 */
	public String getRenewMessage() {
		return renewMessage;
	}

	/**
	 * Returns the renewRequested.
	 * @return boolean
	 */
	public boolean isRenewRequested() {
		return renewRequested;
	}

	/**
	 * Sets the renewAccomplished.
	 * @param renewAccomplished The renewAccomplished to set
	 */
	public void setRenewAccomplished(boolean renewAccomplished) {
		this.renewAccomplished = renewAccomplished;
	}

	/**
	 * Sets the renewMessage.
	 * @param renewMessage The renewMessage to set
	 */
	public void setRenewMessage(String renewMessage) {
		this.renewMessage = renewMessage;
	}

	/**
	 * Sets the renewRequested.
	 * @param renewRequested The renewRequested to set
	 */
	public void setRenewRequested(boolean renewRequested) {
		this.renewRequested = renewRequested;
	}

	/**
	 * Returns the author.
	 * @return String
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * Returns the copyNumber.
	 * @return int
	 */
	public int getCopyNumber() {
		return copyNumber;
	}

	/**
	 * Returns the dueDate.
	 * @return Date
	 */
	public Date getDue() {
		return due;
	}

	/**
	 * Returns the itemId.
	 * @return int
	 */
	public int getItemId() {
		return itemId;
	}

	/**
	 * Returns the timesRenewed.
	 * @return int
	 */
	public int getTimesRenewed() {
		return timesRenewed;
	}

	/**
	 * Returns the title.
	 * @return String
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the author.
	 * @param author The author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * Sets the copyNumber.
	 * @param copyNumber The copyNumber to set
	 */
	public void setCopyNumber(int copyNumber) {
		this.copyNumber = copyNumber;
	}

	/**
	 * Sets the dueDate.
	 * @param dueDate The dueDate to set
	 */
	public void setDue(Date due) {
		this.due = due;
	}

	/**
	 * Sets the itemId.
	 * @param itemId The itemId to set
	 */
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	/**
	 * Sets the timesRenewed.
	 * @param timesRenewed The timesRenewed to set
	 */
	public void setTimesRenewed(int timesRenewed) {
		this.timesRenewed = timesRenewed;
	}

	/**
	 * Sets the title.
	 * @param title The title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
}
