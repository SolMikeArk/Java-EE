package com.ibm.library.datastore;


import java.util.Collection;

import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.Item;
import com.ibm.library.model.exceptions.ItemExists;
import com.ibm.library.model.exceptions.ItemNotFound;


public interface ItemDatastore {
	Item findById(int id) throws ItemNotFound, SystemUnavailableException;
	void add(Item item) throws ItemExists, SystemUnavailableException;
	void remove(Item item) throws ItemNotFound, SystemUnavailableException;
	void update(Item item) throws ItemExists, ItemNotFound, SystemUnavailableException;
	Collection getCopies(Item item) throws ItemNotFound, SystemUnavailableException;
}