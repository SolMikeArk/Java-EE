package com.ibm.library.datastore;


import java.util.Collection;

import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.Patron;
import com.ibm.library.model.exceptions.PatronExists;
import com.ibm.library.model.exceptions.PatronNotFound;


public interface PatronDatastore {
	Patron findById(int id) throws PatronNotFound, SystemUnavailableException;
	Patron findByEmail(String email) throws PatronNotFound, SystemUnavailableException;
	void add(Patron patron) throws PatronExists, SystemUnavailableException;
	void remove(Patron patron) throws PatronNotFound, SystemUnavailableException;
	void update(Patron patron) throws PatronExists, PatronNotFound, SystemUnavailableException;
	Collection getCopies(Patron patron) throws SystemUnavailableException;
	Collection retrieveLoanedCopyies(Patron patron) throws SystemUnavailableException;
}


