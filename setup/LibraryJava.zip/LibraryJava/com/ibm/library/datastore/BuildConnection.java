package com.ibm.library.datastore;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author vogeld
 *
 * This interface is used to hide the deails of how a Connection
 * is created.
 */

public interface BuildConnection {
	Connection getConnection() throws SQLException;
}
