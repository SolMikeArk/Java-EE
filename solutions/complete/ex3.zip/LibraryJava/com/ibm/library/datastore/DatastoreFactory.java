package com.ibm.library.datastore;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.PropertyResourceBundle;

import com.ibm.library.datastore.jdbc.CopyDatastoreJDBC;
import com.ibm.library.datastore.jdbc.ItemDatastoreJDBC;
import com.ibm.library.datastore.jdbc.PatronDatastoreJDBC;
import com.ibm.library.utilities.Trace;

public class DatastoreFactory {
	// resource bundle keys
	private static final String TYPE = "type";
	private static final String TYPE_EJB = "ejb";
	private static final String TYPE_POOL = "pool";
	private static final String TYPE_JDBC = "jdbc";
	// properties for type jdbc
	private static final String USERID = "userid";
	private static final String PASSWORD = "password";
	private static final String DRIVER = "driver";
	private static final String URL = "url";
	// properties for types pool and ejb
	private static final String FACTORY = "initialContextFactory";
	private static final String LOOKUPURL = "lookupURL";
	private static final String LOOKUP = "lookupName";

	// default values to use if no properties bundle is found
	// or keys are missing in properties bundle
	private static String type = "jdbc";
	private static String userid = "USERID";
	private static String password = "PASSWORD";
	private static String driver = "COM.ibm.db2.jdbc.app.DB2Driver";
	private static String url = "jdbc:db2:library";
	private static String contextFactory =
		"COM.ibm.db2.jndi.WsnInitialContextFactory";
	private static String lookupURL = "iiop:///";
	private static String lookupName = "java:comp/env/jdbc/library";

	private static final String file = "databaseInformation.properties";
	@SuppressWarnings("unused")
	private static PropertyResourceBundle properties;

	private static PatronDatastore patronDatastore;
	private static ItemDatastore itemDatastore;
	private static CopyDatastore copyDatastore;

	static {
		Trace.message("Static initalizer for DatastoreFactory", Trace.HIGH);
		refresh();
	}

	public static PatronDatastore getPatronDatastore() {
		return patronDatastore;
	}

	public static ItemDatastore getItemDatastore() {
		return itemDatastore;
	}

	public static CopyDatastore getCopyDatastore() {
		return copyDatastore;
	}

	public static void refresh() {
		Trace.message("DatastoreFactory.refresh() called", Trace.HIGH);
		try {
			InputStream inputStream =
				DatastoreFactory.class.getClassLoader().getResourceAsStream(
					file);
			if (inputStream != null) { // the properties bundle file exists
				Properties properties = new Properties();
				properties.load(inputStream);
				type = properties.getProperty(TYPE);
				if (type == null
					|| (!(type.equalsIgnoreCase(TYPE_POOL)
						|| type.equalsIgnoreCase(TYPE_EJB)
						|| type.equalsIgnoreCase(TYPE_JDBC)))) {
					type = TYPE_JDBC;
				}
				if (type.equalsIgnoreCase(TYPE_JDBC)) {
					userid = properties.getProperty(USERID, userid);
					password = properties.getProperty(PASSWORD, password);
					driver = properties.getProperty(DRIVER, driver);
					url = properties.getProperty(URL, url);
				}
				if (type.equalsIgnoreCase(TYPE_EJB)
					|| type.equalsIgnoreCase(TYPE_POOL)) {
					contextFactory =
						properties.getProperty(FACTORY, contextFactory);
					lookupURL = properties.getProperty(LOOKUPURL, lookupURL);
					lookupName = properties.getProperty(LOOKUP, lookupName);
				}
			} else {
				processBundleError(file);
			}

		} catch (IOException ioe) {
			processBundleError(file);
		}

		if (type.equals(TYPE_EJB)) {
			loadEJBImplementation();
		} else {
			loadJDBCImplementation(type);
		}
	}

	private static void processBundleError(String fileName) {
		Trace.message("Resource bundle \"" + fileName + "\" not found");
		Trace.message("Default values for database access will be used");
	}

	private static void loadJDBCImplementation(String type) {
		Trace.message("DatastoreFactory.loadJDBCImplementation", Trace.HIGH);
		try {
			ConnectionFactory factory;
			if (type.equals(TYPE_POOL)) {
				factory =
					new ConnectionFactory(
						contextFactory,
						lookupURL,
						lookupName);
			} else {
				factory = new ConnectionFactory(driver, url, userid, password);
			}
			patronDatastore = new PatronDatastoreJDBC(factory);
			itemDatastore = new ItemDatastoreJDBC(factory);
			copyDatastore = new CopyDatastoreJDBC(factory);
		} catch (ClassNotFoundException cnf) {
			System.err.println("Driver not found");
		}
	}

	private static void loadEJBImplementation() {
		Trace.message("DatastoreFactory.loadEJBImplementation", Trace.HIGH);
		//patronDatastore = new PatronDatastoreEJB();
		Trace.error("This function has not been implemented in this code");
		throw new RuntimeException("There is no EJB support in this version");
	}
}
