package com.ibm.library.datastore;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * @author vogeld
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class DataSourceConnection implements BuildConnection {
	private String factory;
	private String lookupURL;
	private String lookupName;
	private Context context;
	private DataSource dataSource;
	
	public DataSourceConnection(String newFactory, String newLookupURL,  String newLookupName) {
		factory = newFactory;
		lookupURL = newLookupURL;
		lookupName = newLookupName;
	}

	/**
	 * Get the DataSource
	 * @return DataSource
	 */
	private DataSource getDataSource() throws NamingException {
		if (dataSource == null) {
			Context context = getContext();
			dataSource = (DataSource) context.lookup(lookupName);
		}
		return dataSource;
	}

	/**
	 * Get the current Context
	 * @return Context
	 */
	private Context getContext() throws NamingException {
		if (context == null) {
			Hashtable<String, String> env = new Hashtable<String, String>(5);
			env.put(Context.INITIAL_CONTEXT_FACTORY, factory);
			env.put(Context.PROVIDER_URL,lookupURL);
//			env.put("java.naming.factory.initial", factory);
//			env.put("java.naming.provider.url",lookupURL);

			context = new InitialContext(env);
		}
		return context; 
	}

	
	/**
	 * @see com.ibm.ils.library.datastore.BuildConnection#getConnection()
	 */
	public Connection getConnection() throws SQLException {
		Connection connection = null;
		try {
			connection = getDataSource().getConnection();
		} catch (NamingException ne) {
			throw new SQLException("DataSource Unavailable");
		}
		return connection;
	}

}
