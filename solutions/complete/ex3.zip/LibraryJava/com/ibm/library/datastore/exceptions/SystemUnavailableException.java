package com.ibm.library.datastore.exceptions;


public class SystemUnavailableException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9034295374164367840L;
	private Exception nestedException;


	/**
	 * Constructor for SystemUnavailableException
	 */
	public SystemUnavailableException(Exception nestedException) {
		super("System is currently unavailable");
		setNestedException(nestedException);
	}
	
	/**
	 * Gets the nestedException
	 * @return Returns a Exception
	 */
	public Exception getNestedException() {
		return nestedException;
	}
	/**
	 * Sets the nestedException
	 * @param nestedException The nestedException to set
	 */
	private void setNestedException(Exception nestedException) {
		this.nestedException = nestedException;
	}


}


