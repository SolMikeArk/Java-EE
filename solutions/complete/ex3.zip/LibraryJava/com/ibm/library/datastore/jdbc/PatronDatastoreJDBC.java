package com.ibm.library.datastore.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import com.ibm.library.datastore.ConnectionFactory;
import com.ibm.library.datastore.CopyDatastore;
import com.ibm.library.datastore.DatastoreFactory;
import com.ibm.library.datastore.PatronDatastore;
import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.Patron;
import com.ibm.library.model.exceptions.PatronExists;
import com.ibm.library.model.exceptions.PatronNotFound;
import com.ibm.library.utilities.Trace;

public class PatronDatastoreJDBC implements PatronDatastore {
	private String insertPatronSQL = "INSERT INTO LIBRARY.PATRON (PATRON_ID, FIRST_NAME, LAST_NAME, PASSWORD, EMAIL) VALUES(?, ?, ?, ?, ?)";
	private String removePatronByIdSQL = "DELETE FROM LIBRARY.PATRON WHERE PATRON_ID = ?";
	private String findByIdSQL = "SELECT FIRST_NAME, LAST_NAME, PASSWORD, EMAIL FROM LIBRARY.PATRON WHERE PATRON_ID = ?"; 
	private String findByEmailSQL = "SELECT PATRON_ID, FIRST_NAME, LAST_NAME, PASSWORD FROM LIBRARY.PATRON WHERE EMAIL = ?"; 
	private String updatePatronSQL = "UPDATE LIBRARY.PATRON SET FIRST_NAME = ?, LAST_NAME = ?, PASSWORD = ?, EMAIL = ? WHERE PATRON_ID = ?";
	
	private ConnectionFactory factory;
	
	/**
	 * Constructor for PatronAccessJDBC
	 */
	public PatronDatastoreJDBC(ConnectionFactory factory) {
		super();
		setConnectionFactory(factory);
	}

	/**
	 * Find a Patron by the specified id.
	 * @param id Patron id
	 * @return The found Patron
	 * @exception PatronNotFound The Patron with the specified id does not exis
	 * @exception SystemUnavailableException There is a problem accessing the 
	 * system at this time
	 */
	public Patron findById(int id) throws PatronNotFound, SystemUnavailableException {
		Patron result = null;
		Connection connection = null;
		try {
			connection = getConnection();
			result = internalFindById(id, connection);
			commit(connection);
		} catch (SQLException sql) {
			try {
				rollback(connection);
			} catch (SQLException re) {
			}
			throw new SystemUnavailableException(sql);
		}
		return result;
	}
	
	private Patron internalFindById(int id, Connection connection) throws PatronNotFound, SQLException {
		Patron result = null;
		
		// perpare the select
		PreparedStatement query = connection.prepareStatement(findByIdSQL);
		
		// get the result set
		query.setInt(1, id);
		ResultSet resultSet = query.executeQuery();
	
		// process the result set
		if (resultSet.next()) {
			String firstName = resultSet.getString("FIRST_NAME");
			String lastName = resultSet.getString("LAST_NAME");
			String password = resultSet.getString("PASSWORD");
			String email = resultSet.getString("EMAIL");
				
			result = new Patron(id, firstName, lastName, password, email);
			resultSet.close();
			query.close();
		} else {
			query.close();
			throw new PatronNotFound(id);
		}
		return result;
	}

	/**
	 * @see PatronAccess#findByEmail(String)
	 */
	public Patron findByEmail(String email) throws PatronNotFound, SystemUnavailableException {
		Patron result = null;
		Connection connection = null;
		
		try {
			connection = getConnection();
			result = internalFindByEmail(email, connection);
			commit(connection);
		} catch (SQLException sql) {
			try {
				rollback(connection);
			} catch (SQLException re) {
			}
			throw new SystemUnavailableException(sql);
		}
		
		return result;
	}
	
	public Patron internalFindByEmail(String email, Connection connection) throws PatronNotFound, SQLException {
		Patron result = null;	
		// perpare the select
		PreparedStatement query = connection.prepareStatement(findByEmailSQL);
		// get the result set
		query.setString(1, email);
		ResultSet resultSet = query.executeQuery();
	
		// process the result set
		if (resultSet.next()) {
			int id = resultSet.getInt("PATRON_ID");
			String firstName = resultSet.getString("FIRST_NAME");
			String lastName = resultSet.getString("LAST_NAME");
			String password = resultSet.getString("PASSWORD");
				
			result = new Patron(id, firstName, lastName, password, email);
			resultSet.close();
			query.close();
		} else {
			query.close();
			throw new PatronNotFound(email);
		}
		return result;
	}

	/**
	 * @see PatronAccess#add(Patron)
	 */
	public void add(Patron patron) throws PatronExists, SystemUnavailableException {
		// get the perpared insert statement
		Connection connection = null;
		try {
			connection = getConnection();
		
			PreparedStatement insert = connection.prepareStatement(insertPatronSQL);
		
			// do the insert
			try {
				internalAdd(patron, insert);
			} catch (SQLException sql) {
				// process the SQL exception here
				Trace.message("Add Patron failed",Trace.HIGH);
				Trace.message(sql.getMessage(), Trace.HIGH);
				rollback(connection);
				throw new PatronExists(patron.getId());
			}
			commit(connection);
		} catch (SQLException sqlOuter) {
			throw new SystemUnavailableException(sqlOuter);
		}
	}

	private void internalAdd(Patron patron, PreparedStatement insert)
		throws SQLException {
		insert.setInt(1, patron.getId());
		insert.setString(2, patron.getFirstName());
		insert.setString(3, patron.getLastName());
		insert.setString(4, patron.getPassword());
		insert.setString(5, patron.getEmail());
		insert.execute();	
		insert.close();
	}

	/**
	 * @see PatronAccess#remove(Patron)
	 */
	public void remove(Patron patron) throws PatronNotFound, SystemUnavailableException {
		// get the perpared delete statement
		Connection connection = null;
		try {
			connection = getConnection();
	
			PreparedStatement delete = connection.prepareStatement(removePatronByIdSQL);
		
			// do the delete
			try {
				delete.setInt(1, patron.getId());
				delete.execute();
				int updatedRows = delete.getUpdateCount();
				delete.close();
				// Throw an exception if the Patron does not exist
				if (updatedRows == 0) {
					rollback(connection);
					throw new PatronNotFound(patron.getId());
				}
			} catch (SQLException sql) {
				// process the SQL exception here
				Trace.message("Remove Patron failed", Trace.HIGH);
				Trace.message(sql.getMessage(), Trace.HIGH);
				rollback(connection);
				throw new PatronNotFound(patron.getId());
			}
			
			commit(connection);
		} catch (SQLException sqlOuter) {
			throw new SystemUnavailableException(sqlOuter);
		}
	}

	/**
	 * @see PatronAccess#udpate(Patron)
	 */
	public void update(Patron patron) throws PatronExists, PatronNotFound, SystemUnavailableException {
		Connection connection = null;
		try {
			connection = getConnection();
	
			PreparedStatement update = connection.prepareStatement(updatePatronSQL);
		
			// do the update
			try {
				update.setString(1, patron.getFirstName());
				update.setString(2, patron.getLastName());
				update.setString(3, patron.getPassword());
				update.setString(4, patron.getEmail());
				update.setInt(5, patron.getId());
				update.execute();
				int updatedRows = update.getUpdateCount();
				update.close();
				// throw an exception if there Patron does not exist
				if (updatedRows == 0) {
					rollback(connection);
					throw new PatronNotFound(patron.getId());
				}
			} catch (SQLException sql) {
				boolean exists = false;
				
				if (sql.getSQLState().startsWith("23")) {
					exists = true;
				}
				// process the SQL exception here
				Trace.message("Update Patron failed", Trace.HIGH);
				Trace.message(sql.getMessage(), Trace.HIGH);
				rollback(connection);
				if (exists) {
					throw new PatronExists(patron.getEmail());
				} else {
					throw new PatronNotFound(patron.getId());
				}
			}
			
			commit(connection);
		} catch (SQLException sqlOuter) {
			throw new SystemUnavailableException(sqlOuter);
		}
	}	
	
	/**
	 * @see com.ibm.ils.library.datastore.PatronDatastore#copies(Patron)
	 */
	public Collection getCopies(Patron patron) throws SystemUnavailableException {
		Collection list = null;
		CopyDatastore copyDatastore = DatastoreFactory.getCopyDatastore();
		list = copyDatastore.findCopiesForPatronId(patron.getId());
		return list;
	}
	
	/**
	 * @see com.ibm.ils.library.datastore.PatronDatastore#copies(Patron)
	 */
	public Collection retrieveLoanedCopyies(Patron patron) throws SystemUnavailableException {
		Collection list = null;
		CopyDatastore copyDatastore = DatastoreFactory.getCopyDatastore();
		list = copyDatastore.findLoanedCopiesForPatronId(patron.getId());
		return list;
	}
	
	private void commit(Connection connection) throws SQLException {
		try {
			connection.commit();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.err.println("connection.close() failed");
				e.printStackTrace(System.err);
			}
		}
	}
	
	private void rollback(Connection connection) throws SQLException {
		try {
			connection.rollback();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.err.println("connection.close() failed");
				e.printStackTrace(System.err);
			}
		}
	}
	/**
	 * Gets the connection
	 * @return Returns a ConnectionFactory
	 */
	private Connection getConnection() throws SQLException {
		return factory.getConnection();
	}
	
	/**
	 * Sets the factory
	 * @param factory The factory to set
	 */
	private void setConnectionFactory(ConnectionFactory connectionFactory) {
		factory = connectionFactory;
	}
}

