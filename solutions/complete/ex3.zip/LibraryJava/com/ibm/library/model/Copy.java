package com.ibm.library.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import com.ibm.library.datastore.CopyDatastore;
import com.ibm.library.datastore.DatastoreFactory;
import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.exceptions.CopyExists;
import com.ibm.library.model.exceptions.CopyNotFound;
import com.ibm.library.model.exceptions.ItemNotFound;
import com.ibm.library.model.exceptions.PatronNotFound;
import com.ibm.library.model.exceptions.RenewFailed;
import com.ibm.library.utilities.Trace;

/**
 * @author vogeld
 */
public class Copy implements Serializable {
	private static final long serialVersionUID = -6758127005992362455L;
	private static final int MAX_TIMES_RENEWED = 3;
	private static final long DAYS_TO_RENEW = 21;
	private static final long ONE_DAY = 1000*60*60*24;
	
	private boolean loanable;
	private Date due;
	private int timesRenewed;
	private int patronId;
	private int itemId;
	private int copyNumber;

	private static CopyDatastore datastore;

	private static void refresh() {
		Trace.message("Copy.refresh() called", Trace.HIGH);
		datastore = DatastoreFactory.getCopyDatastore();
	}
	
	static {
		Trace.message("Copy static initializer", Trace.HIGH);
		refresh();
	}
	
	/**
	 * Constructor for Copy.
	 */
	public Copy() {
		this(true);
	}

	public Copy(boolean loanable) {
		this(loanable, null, 0);
	}

	public Copy(boolean loanable, Date due,  int timesRenewed) {
		this(0, 0, loanable, due, timesRenewed);
	}
	
	public Copy(int itemId, boolean loanable) {
		this(itemId, 0, loanable, null, 0);
	}
	
	public Copy(int itemId, int copyNumber, boolean loanable, Date due,  int timesRenewed) {
		super();
		setPatronId(0);
		setItemId(itemId);
		setCopyNumber(copyNumber);
		setLoanable(loanable);
		setDue(due);
		setTimesRenewed(timesRenewed);
	}
	
	public void add() throws ItemNotFound, SystemUnavailableException, CopyExists {
		getDatastore().add(this);
	}

	public void remove() throws ItemNotFound, SystemUnavailableException, CopyNotFound {
		getDatastore().remove(this);
	}
	
	public void update() throws ItemNotFound, SystemUnavailableException, CopyNotFound {
		getDatastore().update(this);
	}
	
	public Item getItem() throws ItemNotFound, SystemUnavailableException {
		return getDatastore().getItem(this);
	}
	
	public Patron getPatron() throws PatronNotFound, SystemUnavailableException {
		return getDatastore().getPatron(this);
	}
	
	public void renew() throws CopyNotFound, RenewFailed, SystemUnavailableException {
		// check to make sure the book is not overdue
		Date today = new Date();
		Date due = getDue();
		
		Calendar todayCalendar = Calendar.getInstance();
		Calendar dueCalendar = Calendar.getInstance();
		dueCalendar.setTime(due);
		int todayYear = todayCalendar.get(Calendar.YEAR);
		int todayDayOfYear = todayCalendar.get(Calendar.DAY_OF_YEAR);
		int dueYear = dueCalendar.get(Calendar.YEAR);
		int dueDayOfYear = dueCalendar.get(Calendar.DAY_OF_YEAR);
		
		if (todayYear < dueYear || 
			(todayYear == dueYear && todayDayOfYear <= dueDayOfYear)) {
			// check to make sure the book has not been
			//  renewed too many times
			if (getTimesRenewed() < MAX_TIMES_RENEWED) {
				// renew the book for the standard time
				getDatastore().renew(this, new java.util.Date(today.getTime()+DAYS_TO_RENEW*ONE_DAY));
			} else {
				throw new RenewFailed("Maximum number of renewals exceeded");
			}
		} else {
			throw new RenewFailed("Renewal is not allowed after the due date");
		}
	}

	private static CopyDatastore getDatastore(){
		return datastore;
	}

	/**
	 * Returns the copyNumber.
	 * @return int
	 */
	public int getCopyNumber() {
		return copyNumber;
	}

	/**
	 * Returns the due.
	 * @return Date
	 */
	public Date getDue() {
		return due;
	}

	/**
	 * Returns the loanable.
	 * @return boolean
	 */
	public boolean isLoanable() {
		return loanable;
	}

	/**
	 * Returns the timesRenewed.
	 * @return int
	 */
	public int getTimesRenewed() {
		return timesRenewed;
	}

	/**
	 * Sets the copyNumber.
	 * @param copyNumber The copyNumber to set
	 */
	public void setCopyNumber(int copyNumber) {
		this.copyNumber = copyNumber;
	}

	/**
	 * Sets the due.
	 * @param due The due to set
	 */
	public void setDue(Date due) {
		this.due = due;
	}

	/**
	 * Sets the loanable.
	 * @param loanable The loanable to set
	 */
	public void setLoanable(boolean loanable) {
		this.loanable = loanable;
	}

	/**
	 * Sets the timesRenewed.
	 * @param timesRenewed The timesRenewed to set
	 */
	public void setTimesRenewed(int timesRenewed) {
		this.timesRenewed = timesRenewed;
	}
	/**
	 * Returns the itemId.
	 * @return int
	 */
	public int getItemId() {
		return itemId;
	}

	/**
	 * Sets the itemId.
	 * @param itemId The itemId to set
	 */
	private void setItemId(int itemId) {
		this.itemId = itemId;
	}

	/**
	 * Returns the patronId.
	 * @return int
	 */
	public int getPatronId() {
		return patronId;
	}

	/**
	 * Sets the patronId.
	 * @param patronId The patronId to set
	 */
	private void setPatronId(int patronId) {
		this.patronId = patronId;
	}
}
