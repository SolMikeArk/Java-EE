package com.ibm.library.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;

import com.ibm.library.datastore.DatastoreFactory;
import com.ibm.library.datastore.PatronDatastore;
import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.exceptions.CopyNotFound;
import com.ibm.library.model.exceptions.InvalidPassword;
import com.ibm.library.model.exceptions.PatronExists;
import com.ibm.library.model.exceptions.PatronNotFound;
import com.ibm.library.utilities.Trace;

public class Patron implements Serializable {
	private static final long serialVersionUID = 8649291757610727617L;
	
	private int id;
	private String firstName;
	private String lastName;
	private String password;
	private String email;
	private static PatronDatastore datastore;
	private static final int MIN_PASSWORD_LENGTH = 5;
	
	private static void refresh() {
		Trace.message("Patron.refresh() called", Trace.HIGH);
		datastore = DatastoreFactory.getPatronDatastore();
	}
	
	static {
		Trace.message("Patron static initializer", Trace.HIGH);
		refresh();
	}
	
	/**
	 * Constructor for Patron
	 */
	public Patron() {
		this("","","","");
	}
	
	public Patron(String firstName, String lastName, String password, String email) {
		this(0, firstName, lastName, password, email);
	}
	
	public Patron(int id, String firstName, String lastName, String password, String email) {
		super();
		setId(id);
		setFirstName(firstName);
		setLastName(lastName);
		setPassword(password);
		setEmail(email);
	}
	
	/**
	 * Gets the id
	 * @return Returns a int
	 */
	public int getId() {
		return id;
	}
	/**
	 * Sets the id
	 * @param id The id to set
	 */
	private void setId(int id) {
		this.id = id;
	}
	
	private static PatronDatastore getDatastore(){
		return datastore;
	}
	
	public static Patron findById(int id) throws PatronNotFound, SystemUnavailableException {
		return getDatastore().findById(id);
	}
	
	public static Patron findByEmail(String email) throws PatronNotFound, SystemUnavailableException {
		return getDatastore().findByEmail(email);
	}
	
	public void add() throws PatronExists, InvalidPassword, SystemUnavailableException {
		int oldId = getId();
		try {
			setId(LibraryIdGenerator.generateId());
			verifyPassword();
			getDatastore().add(this);
		} catch (PatronExists pe){
			setId(oldId);	// restore the old id
			throw pe;
		}
	}
	
	public void remove() throws PatronNotFound, SystemUnavailableException {
		getDatastore().remove(this);
	}
	
	public void update() throws PatronExists, InvalidPassword, PatronNotFound, SystemUnavailableException {
		verifyPassword();
		getDatastore().update(this);
	}
	
	public void renew(Collection list) throws SystemUnavailableException{
		// iterate trough the collection and call the LoanedCopy renew() method.
		Iterator iterator = list.iterator();
		LoanedCopy copy = null;
		
		while (iterator.hasNext()) {
			copy = (LoanedCopy) iterator.next();
			try {
				if (copy.isRenewRequested()) {
					copy.renew();
				}
			} catch (CopyNotFound nf) {
				copy.setRenewAccomplished(false);
				copy.setRenewMessage(nf.getMessage());
			}
		}
	}
	
	public Collection getCopies() throws SystemUnavailableException {
		return getDatastore().getCopies(this);
	}
	
	public Collection retrieveLoanedCopies() throws SystemUnavailableException {
		return getDatastore().retrieveLoanedCopyies(this);
	}
	
	public static void verifyLogon(int patronId, String password) throws PatronNotFound, InvalidPassword, SystemUnavailableException {
		// first check to see if the patron exists
		Patron patron = findById(patronId);
		// it exists, check the password
		if (! patron.getPassword().equals(password)) {
			// passwords don't match
			throw new InvalidPassword("Password is not valid");
		}
	}
	
	/**
	 * Gets the firstName
	 * @return Returns a String
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * Sets the firstName
	 * @param firstName The firstName to set
	 */
	public void setFirstName(String firstName) {
		if (firstName == null) {
			this.firstName = "";
		} else {
			this.firstName = firstName;;
		}
	}

	/**
	 * Gets the lastName
	 * @return Returns a String
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * Sets the lastName
	 * @param lastName The lastName to set
	 */
	public void setLastName(String lastName) {
		if (lastName == null) {
			this.lastName = "";
		} else {
			this.lastName = lastName;
		}
	}

	/**
	 * Gets the password
	 * @return Returns a String
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * Sets the password
	 * @param password The password to set
	 */
	public void setPassword(String password) {
		if (password == null) {
			this.password = "";
		} else {
			this.password = password;
		}
	}
	
	/**
	 * Verifies the password
	 * @param password The password to be verified.
	 */
	protected void verifyPassword() throws InvalidPassword {
		String password = getPassword();
		// make sure the password is not null and is not of length 0
		if (password == null || password.length() == 0) {
			throw new InvalidPassword("Password is missing");
		}

		// make sure the password does not contain blanks		
		int firstBlank = password.indexOf(" ");
		if (firstBlank >= 0) {
			throw new InvalidPassword("Password contains one or more blank characters");
		}

		// make sure the password is long enough
		if (password.length() < MIN_PASSWORD_LENGTH) {
			throw new InvalidPassword("Password must be at least "+MIN_PASSWORD_LENGTH+" characters long");
		}		
	}

	/**
	 * Gets the email
	 * @return Returns a String
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * Sets the email
	 * @param email The email to set
	 */
	public void setEmail(String email) {
		if (email == null) {
			this.email = "";
		} else {
			this.email = email;
		}
	}
}