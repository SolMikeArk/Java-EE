package com.ibm.library.model.exceptions;
public class PatronExists extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8424755448898010490L;

	/**
	 * Constructor for PatronExists
	 */
	public PatronExists(int id) {
		super("Patron "+id+" already exists");
	}
	
	/**
	 * Constructor for PatronExists
	 */
	public PatronExists(String email) {
		super("Patron "+email+" already exists");
	}

}

