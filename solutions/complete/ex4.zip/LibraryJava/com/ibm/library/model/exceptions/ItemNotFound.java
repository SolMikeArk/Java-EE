package com.ibm.library.model.exceptions;
public class ItemNotFound extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6630707362455826186L;

	/**
	 * Constructor for PatronExists
	 */
	public ItemNotFound(int id) {
		super("Patron "+id+" was not found");
	}
	
	/**
	 * Constructor for PatronExists
	 */
	public ItemNotFound(String email) {
		super("Patron "+email+" was not found");
	}

}

