package com.ibm.library.model;

public class LibraryIdGenerator {

	public static int generateId() {
		// TODO Auto-generated method stub
		return (new Double(Math.floor(1000000*Math.random()))).intValue();
	}

}
