package com.ibm.library.model.exceptions;
public class PatronNotFound extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6728414494596507082L;

	/**
	 * Constructor for PatronExists
	 */
	public PatronNotFound(int id) {
		super("Patron "+id+" was not found");
	}
	
	/**
	 * Constructor for PatronExists
	 */
	public PatronNotFound(String email) {
		super("Patron "+email+" was not found");
	}

}

