package com.ibm.library.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import com.ibm.library.datastore.DatastoreFactory;
import com.ibm.library.datastore.ItemDatastore;
import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.exceptions.ItemExists;
import com.ibm.library.model.exceptions.ItemNotFound;
import com.ibm.library.utilities.Trace;

/**
 * @author vogeld
 *
 * Represents an item (book, CD, DVD, audio tape, etc.) in the
 * library.
 */
public class Item implements Serializable {
	private static final long serialVersionUID = 7406392623379530863L;
	// the following string must contain all of the public final static char values
	// order is not important
	private final static String mediumValues = "?BACDV";
	public final static char UNKNOWN = '?';
	public final static char BOOK = 'B';
	public final static char AUDIO = 'A';
	public final static char CD = 'C';
	public final static char DVD = 'D';
	public final static char VIDEO = 'V';

	private int id;
	private char medium;
	private String isbnEquivalent;
	private String title;
	private String author;
	private boolean oversize;
	private int volumes;
	private Date published;
	
	private static ItemDatastore datastore;
		
	private static void refresh() {
		datastore = DatastoreFactory.getItemDatastore();
	}
	
	static {
		Trace.message("Item static initializer", Trace.HIGH);
		refresh();
	}
	
	/**
	 * Constructor for Item.
	 */
	public Item() {
		this(UNKNOWN,null,"","",false,1,null);
	}
	
	public Item(char medium, String isbnEquivalent, String title, String author, boolean oversize, int volumes, Date published) {
		this(0, medium, isbnEquivalent, title, author, oversize, volumes, published);
	}
	
	public Item(int id, char medium, String isbnEquivalent, String title, String author, boolean oversize, int volumes, Date published) { 
		setId(id);
		setMedium(medium);
		setIsbnEquivalent(isbnEquivalent);
		setTitle(title);
		setAuthor(author);
		setOversize(oversize);
		setVolumes(volumes);
		setPublished(published);
	}
	
	public void add() throws SystemUnavailableException, ItemExists {
		int oldId = getId();
		try {
			getDatastore().add(this);
		} catch (ItemExists ie){
			setId(oldId);	// restore the old id
			throw ie;
		}
	}
	
	public void remove() throws ItemNotFound, SystemUnavailableException {
		getDatastore().remove(this);
	}
	
	public void update() throws SystemUnavailableException, ItemNotFound, ItemExists {
		getDatastore().update(this);
	}

	public Collection getCopies() throws SystemUnavailableException, ItemNotFound {
		return getDatastore().getCopies(this);
	}
	
	public static Item findById(int id) throws ItemNotFound, SystemUnavailableException {
		return getDatastore().findById(id);
	}
	
	private static ItemDatastore getDatastore(){
		return datastore;
	}
	
	/**
	 * Returns the author.
	 * @return String
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * Returns the id.
	 * @return int
	 */
	public int getId() {
		return id;
	}

	/**
	 * Returns the isbnEquivalent.
	 * @return String
	 */
	public String getIsbnEquivalent() {
		return isbnEquivalent;
	}

	/**
	 * Returns the medium.
	 * @return char
	 */
	public char getMedium() {
		return medium;
	}

	/**
	 * Returns the oversize.
	 * @return boolean
	 */
	public boolean isOversize() {
		return oversize;
	}

	/**
	 * Returns the published.
	 * @return Date
	 */
	public Date getPublished() {
		return published;
	}

	/**
	 * Returns the title.
	 * @return String
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Returns the volumes.
	 * @return int
	 */
	public int getVolumes() {
		return volumes;
	}

	/**
	 * Sets the author.
	 * @param author The author to set
	 */
	public void setAuthor(String author) {
		if (author == null) {
			author = "";
		}
		this.author = author;
	}

	/**
	 * Sets the id.
	 * @param id The id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Sets the isbnEquivalent.
	 * @param isbnEquivalent The isbnEquivalent to set
	 */
	public void setIsbnEquivalent(String isbnEquivalent) {
		this.isbnEquivalent = isbnEquivalent;
	}

	/**
	 * Sets the medium.
	 * @param medium The medium to set
	 */
	public void setMedium(char medium) {
		// verify the input value for medium.
		String checkValue = String.valueOf(medium).toUpperCase();
		int index = mediumValues.indexOf(checkValue);
		if (index < 0) {
			index = UNKNOWN;
		}
		this.medium = medium;
	}

	/**
	 * Sets the oversize.
	 * @param oversize The oversize to set
	 */
	public void setOversize(boolean oversize) {
		this.oversize = oversize;
	}

	/**
	 * Sets the published.
	 * @param published The published to set
	 */
	public void setPublished(Date published) {
		this.published = published;
	}

	/**
	 * Sets the title.
	 * @param title The title to set
	 */
	public void setTitle(String title) {
		if (title == null) {
			title = "";
		}
		this.title = title;
	}

	/**
	 * Sets the volumes.
	 * @param volumes The volumes to set
	 */
	public void setVolumes(int volumes) {
		this.volumes = volumes;
	}

}
