package com.ibm.library.datastore;

import java.sql.Connection;
import java.sql.SQLException;

public class ConnectionFactory {
	private String driver;
	private String url;
	private String userid;
	private String password;
	private String factory;
	private String name;
	private BuildConnection delegate;

	public final static int JDBC = 0;
	public final static int POOL = 1;
		
	/**
	 * Constructor for ConnectionFactory
	 */
	public ConnectionFactory(String driver, String url, String userid, String password) throws ClassNotFoundException {
		super();
		setUserid(userid);
		setPassword(password);
		setupJdbc(driver, url);
	}
	/**
	 * Constructor for ConnectionFactory
	 */
	public ConnectionFactory(String factory, String lookupURL, String lookupName) throws ClassNotFoundException {
		super();
	    setupPool(factory, lookupURL, lookupName);
	}

	/**
	 * Method setupPool.
	 * @param factory
	 * @param lookupName
	 */
	private void setupPool(String factory, String lookupURL, String lookupName) {
		setFactory(factory);
		setName(lookupName);
		setDelegate(new DataSourceConnection(factory, lookupURL, lookupName));
	}


	/**
	 * Method setupJDBC.
	 * @param driver
	 * @param url
	 */
	private void setupJdbc(String driver, String url) throws ClassNotFoundException {
		setDriver(driver);
		setUrl(url);
		setDelegate(new DriverManagerConnection(driver, url, userid, password));
	}

	
	public Connection getConnection() throws SQLException {
		Connection connection = delegate.getConnection();
		connection.setAutoCommit(false);
		return connection;
	}

	/**
	 * Gets the url
	 * @return Returns a String
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * Sets the url
	 * @param url The url to set
	 */
	private void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Gets the userid
	 * @return Returns a String
	 */
	public String getUserid() {
		return userid;
	}
	/**
	 * Sets the userid
	 * @param userid The userid to set
	 */
	private void setUserid(String userid) {
		this.userid = userid;
	}

	/**
	 * Gets the password
	 * @return Returns a String
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * Sets the password
	 * @param password The password to set
	 */
	private void setPassword(String password) {
		this.password = password;
	}


	/**
	 * Gets the driver
	 * @return Returns a String
	 */
	public String getDriver() {
		return driver;
	}
	/**
	 * Sets the driver
	 * @param driver The driver to set
	 */
	private void setDriver(String driver) throws ClassNotFoundException  {
		// set this as the current driver
		this.driver = driver;
	}
	/**
	 * Returns the delegate.
	 * @return BuildConnection
	 */
	@SuppressWarnings("unused")
	private BuildConnection getDelegate() {
		return delegate;
	}

	/**
	 * Sets the delegate.
	 * @param delegate The delegate to set
	 */
	private void setDelegate(BuildConnection delegate) {
		this.delegate = delegate;
	}

	/**
	 * Returns the factory.
	 * @return String
	 */
	public String getFactory() {
		return factory;
	}

	/**
	 * Returns the name.
	 * @return String
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the factory.
	 * @param factory The factory to set
	 */
	private void setFactory(String factory) {
		this.factory = factory;
	}

	/**
	 * Sets the name.
	 * @param name The name to set
	 */
	private void setName(String name) {
		this.name = name;
	}

}

