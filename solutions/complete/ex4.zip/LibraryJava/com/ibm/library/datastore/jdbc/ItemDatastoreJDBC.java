package com.ibm.library.datastore.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collection;

import com.ibm.library.datastore.ConnectionFactory;
import com.ibm.library.datastore.CopyDatastore;
import com.ibm.library.datastore.DatastoreFactory;
import com.ibm.library.datastore.ItemDatastore;
import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.Item;
import com.ibm.library.model.exceptions.ItemExists;
import com.ibm.library.model.exceptions.ItemNotFound;
import com.ibm.library.utilities.Trace;

/**
 * @author vogeld
 *
 * JDBC support for the LIBRARY.ITEM table
 */
public class ItemDatastoreJDBC implements ItemDatastore {
	private final String OVERSIZED = "O";
	private final String STANDARD = "S";
	private String findMaxId = "SELECT MAX(ITEM_KEY) FROM LIBRARY.ITEM";
	private String insertItemSQL = "INSERT INTO LIBRARY.ITEM (ITEM_KEY, TYPE, ISBN_EQUIV, TITLE, AUTHOR, OVERSIZE, VOLUMES, PUBLISH_DATE ) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
	private String removeItemByIdSQL = "DELETE FROM LIBRARY.ITEM WHERE ITEM_KEY = ?";
	private String findByIdSQL = "SELECT TYPE, ISBN_EQUIV, TITLE, AUTHOR, OVERSIZE, VOLUMES, PUBLISH_DATE FROM LIBRARY.ITEM WHERE ITEM_KEY = ?"; 
	private String findByTitleAuthorISBNSQL = "SELECT ITEM_KEY FROM LIBRARY.ITEM WHERE TITLE = ? AND AUTHOR = ? AND ISBN_EQUIV = ?"; 
	private String updateItemSQL = "UPDATE LIBRARY.ITEM SET TYPE = ?, ISBN_EQUIV = ?, TITLE = ?, AUTHOR = ?, OVERSIZE = ?, VOLUMES = ?, PUBLISH_DATE = ? WHERE ITEM_KEY = ?";
	
	private ConnectionFactory factory;

	/**
	 * Constructor ItemDatastoreJDBC.
	 * @param factory
	 */
	public ItemDatastoreJDBC(ConnectionFactory factory) {
		super();
		setConnectionFactory(factory);
	}
	
	/**
	 * Find an Item by the specified id.
	 * @param id Item id
	 * @return The found Item
	 * @exception ItemNotFound The Item with the specified id does not exis
	 * @exception SystemUnavailableException There is a problem accessing the 
	 * system at this time
	 */
	public Item findById(int id) throws ItemNotFound, SystemUnavailableException {
		Item result = null;
		Connection connection = null;
		try {
			connection = getConnection();
			result = internalFindById(id, connection);
			commit(connection);
		} catch (SQLException sql) {
			try {
				rollback(connection);
			} catch (SQLException re) {
			}
			throw new SystemUnavailableException(sql);
		}
		return result;
	}
	
	private Item internalFindById(int id, Connection connection) throws ItemNotFound, SQLException {
		Item result = null;
		
		// perpare the select
		PreparedStatement query = connection.prepareStatement(findByIdSQL);
		
		// get the result set
		query.setInt(1, id);
		ResultSet resultSet = query.executeQuery();

		char type;
		String isbnEquivalent;
		String title;
		String author;
		String overString;
		boolean oversize;
		int volumes;
		Date publishDate;

		// process the result set
		if (resultSet.next()) {
			type = resultSet.getString(1).charAt(0);
			isbnEquivalent = resultSet.getString(2);
			if (resultSet.wasNull()) {
				isbnEquivalent = null;
			}
			title = resultSet.getString(3);
			author = resultSet.getString(4);
			overString = resultSet.getString(5);
			if (overString.toUpperCase().equals(OVERSIZED)) {
				oversize = true;
			} else { 
				oversize = false;
			}
			volumes = resultSet.getInt(6);
			if (resultSet.wasNull()) {
				volumes = 0;
			}
			publishDate = resultSet.getDate(7);
			if (resultSet.wasNull()) {
				publishDate = null;
			}
			result = new Item(id, type, isbnEquivalent, title, author, oversize, volumes, publishDate);
			resultSet.close();
			query.close();
		} else {
			query.close();
			throw new ItemNotFound(id);
		}
		return result;
	}


	/**
	 * @see com.ibm.ils.library.datastore.ItemDatastore#add(Item)
	 */
	public void add(Item item) throws ItemExists, SystemUnavailableException {
		int oldIsolationLevel = Connection.TRANSACTION_READ_COMMITTED;
		Connection connection = null;
		@SuppressWarnings("unused")
		int id = 0;
		boolean found;
		
		try {
			connection = getConnection();
		
			// set isolation level to repeatable read
			oldIsolationLevel = connection.getTransactionIsolation();
			connection.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
			
			// check to see if the item already exists
			found = internalFindItem(item, connection);
			
			if (found) {
				connection.setTransactionIsolation(oldIsolationLevel);
				rollback(connection);
				throw new ItemExists(item.getId());
			} else {
				internalAdd(item, connection);
				connection.setTransactionIsolation(oldIsolationLevel);
				commit(connection);
			}
		} catch (SQLException sqlOuter) {
			try {
				connection.setTransactionIsolation(oldIsolationLevel);
				rollback(connection);
			} catch (SQLException re) {
			}
			throw new SystemUnavailableException(sqlOuter);
		}
	}

	private void internalAdd(Item item, Connection connection) throws SQLException {
		int id;
		id = getNextId(connection);
		PreparedStatement insert = connection.prepareStatement(insertItemSQL);
		
		// do the insert
		String oversize;
		insert.setInt(1, id);
		insert.setString(2, String.valueOf(item.getMedium()));
		String isbnEquivalent = item.getIsbnEquivalent();
		if (isbnEquivalent == null) {
			insert.setNull(3, Types.VARCHAR);
		} else {
			insert.setString(3, isbnEquivalent);
		}
		insert.setString(4, item.getTitle());
		insert.setString(5, item.getAuthor());
		if (item.isOversize()) {
			oversize = OVERSIZED;
		} else {
			oversize = STANDARD;
		}
		insert.setString(6, oversize);
		if (item.getVolumes() == 0) {
			insert.setNull(7, Types.INTEGER);
		} else {
			insert.setInt(7, item.getVolumes());
		}
		java.util.Date published = item.getPublished();
		if (published == null) {
			insert.setNull(8, Types.DATE);
		} else {
			insert.setDate(8, new Date(published.getTime()));
		}
		insert.execute();	
		item.setId(id);
		insert.close();
	}

	/**
	 * Method internalFindByTitleAuthorISBNEquivalent.
	 * @param item
	 */
	private boolean internalFindItem(Item item, Connection connection) throws SQLException {
		int itemKey;
		boolean result = false;
		PreparedStatement query = connection.prepareStatement(findByTitleAuthorISBNSQL);
		// get the result set
		query.setString(1, item.getTitle());
		query.setString(2, item.getAuthor());
		query.setString(3, item.getIsbnEquivalent());
		
		// do the query
		ResultSet resultSet = query.executeQuery();
	
		// process the result set
		if (resultSet.next()) {
			itemKey = resultSet.getInt(1); 
			item.setId(itemKey);			
			resultSet.close();
			query.close();
			result = true;
		} else {
			query.close();
			result = false;
		}
		return result;
	}

	/**
	 * Method getNextId.
	 * @return int
	 */
	private int getNextId(Connection connection) throws SQLException {
		int maxId;
		PreparedStatement query = connection.prepareStatement(findMaxId);
		// get the result set
		ResultSet resultSet = query.executeQuery();
	
		// process the result set
		if (resultSet.next()) {
			maxId = resultSet.getInt(1);
			resultSet.close();
			query.close();
		} else {
			query.close();
			throw new SQLException("Cannot determine the new item key");
		}

		return maxId+1;
	}

	/**
	 * @see com.ibm.ils.library.datastore.ItemDatastore#remove(Item)
	 */
	public void remove(Item item) throws ItemNotFound, SystemUnavailableException {
		// get the perpared delete statement
		Connection connection = null;
		try {
			connection = getConnection();
	
			PreparedStatement delete = connection.prepareStatement(removeItemByIdSQL);
		
			// do the delete
			try {
				delete.setInt(1, item.getId());
				delete.execute();
				int updatedRows = delete.getUpdateCount();
				delete.close();
				// Throw an exception if the Patron does not exist
				if (updatedRows == 0) {
					rollback(connection);
					throw new ItemNotFound(item.getId());
				}
			} catch (SQLException sql) {
				// process the SQL exception here
				Trace.message("Remove Item failed", Trace.HIGH);
				Trace.message(sql.getMessage(), Trace.HIGH);
				rollback(connection);
				throw new ItemNotFound(item.getId());
			}
			commit(connection);
		} catch (SQLException sqlOuter) {
			throw new SystemUnavailableException(sqlOuter);
		}
	}

	/**
	 * @see com.ibm.ils.library.datastore.ItemDatastore#update(Item)
	 */
	public void update(Item item) throws ItemExists, ItemNotFound, SystemUnavailableException {
		Connection connection = null;
		try {
			connection = getConnection();
	
			PreparedStatement update = connection.prepareStatement(updateItemSQL);
				
			// do the update
			String isbnEquivalent;
			String oversize;
			int volumes;
			java.util.Date publishDate;
	
			try {
				update.setString(1, String.valueOf(item.getMedium()));
				isbnEquivalent = item.getIsbnEquivalent();
				if (isbnEquivalent == null) {
					update.setNull(2, Types.VARCHAR);
				} else {
					update.setString(2, isbnEquivalent);
				}
				update.setString(3, item.getTitle());
				update.setString(4, item.getAuthor());
				if (item.isOversize()) {
					oversize = OVERSIZED;
				} else {
					oversize = STANDARD;
				}
				update.setString(5, oversize);
				volumes = item.getVolumes();
				if (volumes == 0) {
					update.setNull(6, Types.INTEGER);
				} else {
					update.setInt(6, volumes);
				}
				publishDate = item.getPublished();
				if (publishDate == null) {
					update.setNull(7, Types.DATE);
				} else {
					update.setDate(7, new Date(publishDate.getTime()));
				}
				update.setInt(8, item.getId());
				update.execute();
				int updatedRows = update.getUpdateCount();
				update.close();
				// throw an exception if there Patron does not exist
				if (updatedRows == 0) {
					rollback(connection);
					throw new ItemNotFound(item.getId());
				}
			} catch (SQLException sql) {
				boolean exists = false;
				
				if (sql.getSQLState().startsWith("23")) {
					exists = true;
				}
				// process the SQL exception here
				Trace.message("Update Item failed", Trace.HIGH);
				Trace.message(sql.getMessage(), Trace.HIGH);
				rollback(connection);
				if (exists) {
					throw new ItemExists(item.getId());
				} else {
					throw new ItemNotFound(item.getId());
				}
			}
			commit(connection);
		} catch (SQLException sqlOuter) {
			throw new SystemUnavailableException(sqlOuter);
		}
	}

	/**
	 * @see com.ibm.ils.library.datastore.ItemDatastore#getCopies(Item)
	 */
	public Collection getCopies(Item item)throws ItemNotFound, SystemUnavailableException {
		Collection list = null;
		CopyDatastore copyDatastore = DatastoreFactory.getCopyDatastore();
		list = copyDatastore.findCopiesForItemId(item.getId());
		return list;
	}

	/**
	 * Gets the connection
	 * @return Returns a ConnectionFactory
	 */
	private Connection getConnection() throws SQLException {
		return getConnectionFactory().getConnection();
	}

	/**
	 * Returns the factory.
	 * @return ConnectionFactory
	 */
	public ConnectionFactory getConnectionFactory() {
		return factory;
	}

	/**
	 * Sets the factory.
	 * @param factory The factory to set
	 */
	public void setConnectionFactory(ConnectionFactory factory) {
		this.factory = factory;
	}
	
	private void commit(Connection connection) throws SQLException {
		try {
			connection.commit();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.err.println("connection.close() failed");
				e.printStackTrace(System.err);
			}
		}
	}
	
	private void rollback(Connection connection) throws SQLException {
		try {
			connection.rollback();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.err.println("connection.close() failed");
				e.printStackTrace(System.err);
			}
		}
	}
}
