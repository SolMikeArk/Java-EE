package com.ibm.library.datastore.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ibm.library.datastore.ConnectionFactory;
import com.ibm.library.datastore.CopyDatastore;
import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.Copy;
import com.ibm.library.model.Item;
import com.ibm.library.model.LoanedCopy;
import com.ibm.library.model.Patron;
import com.ibm.library.model.exceptions.CopyExists;
import com.ibm.library.model.exceptions.CopyNotFound;
import com.ibm.library.model.exceptions.ItemNotFound;
import com.ibm.library.model.exceptions.PatronNotFound;
import com.ibm.library.utilities.Trace;

/**
 * @author vogeld
 *
 * JDBC support for the LIBRARY.ITEM table
 */
public class CopyDatastoreJDBC implements CopyDatastore {
	private String insertCopySQL = "INSERT INTO LIBRARY.COPY (ITEM_KEY, COPY_NUMBER, LOANABLE) VALUES(?, ?, ?)";
	private String removeCopySQL = "DELETE FROM LIBRARY.COPY WHERE ITEM_KEY = ? AND COPY_NUMBER = ?";
	// the following have not been implemented yet
	@SuppressWarnings("unused")
	private String findByItemIdCopyIdSQL = 
		"SELECT COPY.ITEM_KEY, COPY.COPY_NUMBER, ITEM.TITLE, ITEM.AUTHOR, ONLOAN.TIMES_RENEWED, ONLOAN.DUE_DATE "+
			"FROM LIBRARY.COPY COPY, LIBRARY.ONLOAN ONLOAN, LIBRARY.ITEM ITEM "+
			"WHERE COPY.ITEM_KEY = ONLOAN.ITEM_KEY "+
				  "AND COPY.ITEM_KEY = ITEM.ITEM_KEY "+
				  "AND COPY.COPY_NUMBER = ONLOAN.COPY_NUMBER "+
				  "AND COPY.ITEM_KEY = ? "+
				  "AND COPY.COPY_NUMBER = ?";
	//
	private String findMaxId = "SELECT MAX(COPY_NUMBER) FROM LIBRARY.COPY WHERE ITEM_KEY = ?";
	private String findCopiesForPatronId = 
		"SELECT COPY.ITEM_KEY, COPY.COPY_NUMBER, COPY.LOANABLE, ONLOAN.TIMES_RENEWED, ONLOAN.DUE_DATE "+
			"FROM LIBRARY.COPY COPY, LIBRARY.ONLOAN ONLOAN "+
			"WHERE COPY.ITEM_KEY = ONLOAN.ITEM_KEY "+
				  "AND COPY.COPY_NUMBER = ONLOAN.COPY_NUMBER "+
				  "AND ONLOAN.PATRON_ID = ? "+
			"ORDER BY COPY.ITEM_KEY, COPY.COPY_NUMBER";
	private String findCopiesForItemId = 
		"SELECT COPY.ITEM_KEY, COPY.COPY_NUMBER, COPY.LOANABLE, ONLOAN.TIMES_RENEWED, ONLOAN.DUE_DATE "+
			"FROM LIBRARY.COPY COPY LEFT OUTER JOIN LIBRARY.ONLOAN ONLOAN "+
			"ON COPY.ITEM_KEY = ONLOAN.ITEM_KEY "+
			   "AND COPY.COPY_NUMBER = ONLOAN.COPY_NUMBER "+
			"WHERE COPY.ITEM_KEY = ? "+
			"ORDER BY COPY.COPY_NUMBER";
	private String findLoanedCopiesForPatronId = 
		"SELECT COPY.ITEM_KEY, COPY.COPY_NUMBER, ITEM.TITLE, ITEM.AUTHOR, ONLOAN.TIMES_RENEWED, ONLOAN.DUE_DATE "+
			"FROM LIBRARY.COPY COPY, LIBRARY.ONLOAN ONLOAN, LIBRARY.ITEM ITEM "+
			"WHERE COPY.ITEM_KEY = ONLOAN.ITEM_KEY "+
				  "AND COPY.ITEM_KEY = ITEM.ITEM_KEY "+
				  "AND COPY.COPY_NUMBER = ONLOAN.COPY_NUMBER "+
				  "AND ONLOAN.PATRON_ID = ? "+
			" ORDER BY ITEM.TITLE, ITEM.AUTHOR";
	private String updateRenew = "UPDATE LIBRARY.ONLOAN SET TIMES_RENEWED=?, DUE_DATE = ? WHERE ITEM_KEY = ? AND COPY_NUMBER = ? AND TIMES_RENEWED = ? AND DUE_DATE = ?";
	@SuppressWarnings("unused")
	private String updateCopy = "UPDATE LIBRARY.COPY SET xx=?, yy=? WHERE ITEM_KEY = ? AND COPY_NUMBER = ?";
	@SuppressWarnings("unused")
	private String updateOnloan = "UPDATE LIBRARY.ONLOAN SET xx=?, yy=? WHERE ITEM_KEY = ? AND COPY_NUMBER = ?";

	private ConnectionFactory factory;

	/**
	 * Constructor ItemDatastoreJDBC.
	 * @param factory
	 */
	public CopyDatastoreJDBC(ConnectionFactory factory) {
		super();
		setConnectionFactory(factory);
	}
	
	/**
	 * @see com.ibm.ils.library.datastore.CopyDatastore#add(int, Copy)
	 */
	public void add(Copy copy) throws CopyExists, ItemNotFound, SystemUnavailableException {
		int oldIsolationLevel = Connection.TRANSACTION_READ_COMMITTED;
		Connection connection = null;
		@SuppressWarnings("unused")
		int id = 0;
		@SuppressWarnings("unused")
		boolean found;
		
		try {
			connection = getConnection();
		
			// set isolation level to repeatable read
			oldIsolationLevel = connection.getTransactionIsolation();
			connection.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
			
			internalAdd(copy, connection);
			connection.setTransactionIsolation(oldIsolationLevel);
			commit(connection);
		} catch (SQLException sqlOuter) {
			try {
				connection.setTransactionIsolation(oldIsolationLevel);
				rollback(connection);
			} catch (SQLException re) {
			}
			throw new SystemUnavailableException(sqlOuter);
		}
	}

	private void internalAdd(Copy copy, Connection connection) throws SQLException {
		int copyNumber;
		copyNumber = getNextId(copy.getItemId(), connection);
		PreparedStatement insert = connection.prepareStatement(insertCopySQL);
		
		// do the insert
		insert.setInt(1, copy.getItemId());
		insert.setInt(2, copyNumber);
		
		String loanable;
		if (copy.isLoanable()) {
			loanable = "T";
		} else {
			loanable = "F";
		}
		insert.setString(3, loanable);
		insert.execute();	
		copy.setCopyNumber(copyNumber);
		insert.close();
	}

	/**
	 * @see com.ibm.ils.library.datastore.CopyDatastore#remove(Copy)
	 */
	public void remove(Copy copy) throws CopyNotFound, ItemNotFound, SystemUnavailableException {
		// NOTE:  This method REALLY needs to check to see if the copy is on loan first before it is remove
		// get the perpared delete statement
		Connection connection = null;
		try {
			connection = getConnection();
	
			PreparedStatement delete = connection.prepareStatement(removeCopySQL);
		
			// do the delete
			try {
				delete.setInt(1, copy.getItemId());
				delete.setInt(2, copy.getCopyNumber());
				delete.execute();
				int updatedRows = delete.getUpdateCount();
				delete.close();
				// Throw an exception if the Patron does not exist
				if (updatedRows == 0) {
					rollback(connection);
					throw new CopyNotFound(copy.getItemId(), copy.getCopyNumber());
				}
			} catch (SQLException sql) {
				// process the SQL exception here
				Trace.message("Remove Item failed", Trace.HIGH);
				Trace.message(sql.getMessage(), Trace.HIGH);
				rollback(connection);
				throw new CopyNotFound(copy.getItemId(), copy.getCopyNumber());
			}
			commit(connection);
		} catch (SQLException sqlOuter) {
			throw new SystemUnavailableException(sqlOuter);
		}
	}
	
	/**
	 * @see com.ibm.ils.library.datastore.CopyDatastore#update(Copy)
	 */
	public void update(Copy copy)throws CopyNotFound, ItemNotFound, SystemUnavailableException {
		throw new SystemUnavailableException(new Exception("Function not implemented"));
	}
	
	/**
	 * @see com.ibm.ils.library.datastore.CopyDatastore#getItem(Copy)
	 */
	public Item getItem(Copy copy) throws ItemNotFound, SystemUnavailableException {
		throw new SystemUnavailableException(new Exception("Function not implemented"));
	}

	/**
	 * @see com.ibm.ils.library.datastore.CopyDatastore#getPatron(Copy)
	 */
	public Patron getPatron(Copy copy) throws PatronNotFound, SystemUnavailableException {
		throw new SystemUnavailableException(new Exception("Function not implemented"));
	}
	
	/**
	 * @see com.ibm.ils.library.datastore.CopyDatastore#findCopiesForPatronId(int)
	 */
	public Collection<Copy> findCopiesForPatronId(int patronId) throws SystemUnavailableException {
		Copy copy = null;
		Connection connection = null;
		ResultSet result = null;
		int itemId = 0;
		int copyNumber = 0;
		String loanable = null;
		boolean isLoanable = false;
		int timesRenewed = 0;
		Date dueDate = null;
		
		List<Copy> copies = new ArrayList<Copy>();
		
		try {
			connection = getConnection();
			PreparedStatement query = connection.prepareStatement(findCopiesForPatronId);
			query.setInt(1, patronId);
		
			result = query.executeQuery();
		
			while (result.next()) {
				itemId = result.getInt(1);
				copyNumber = result.getInt(2);
				loanable = result.getString(3);
				timesRenewed = result.getInt(4);
				dueDate = result.getDate(5);
				java.util.Date dueUtilDate = (dueDate == null) ? null : new java.util.Date(dueDate.getTime());
				
				if (loanable.toUpperCase().equals("T")) {
					isLoanable = true;
				} else {
					isLoanable = false;
				}
				copy = new Copy(itemId, copyNumber, isLoanable,dueUtilDate, timesRenewed);
				copies.add(copy);
			}
			
			query.close();
			result.close();
			commit(connection);
		} catch (SQLException sql) {
			Trace.error(sql);
			try {
				rollback(connection);
			} catch (SQLException re) {
			}
			throw new SystemUnavailableException(sql);
		}		
		
		return copies;
	}
	
	/**
	 * Find the LoanedCopy items for a given patron id
	 */
	public Collection<LoanedCopy> findLoanedCopiesForPatronId(int patronId) throws SystemUnavailableException {
		LoanedCopy copy = null;
		Connection connection = null;
		ResultSet result = null;
		int itemId = 0;
		int copyNumber = 0;
		String title = null;
		String author = null;
		int timesRenewed = 0;
		Date dueDate = null;
		
		List<LoanedCopy> copies = new ArrayList<LoanedCopy>();
		
		try {
			connection = getConnection();
			PreparedStatement query = connection.prepareStatement(findLoanedCopiesForPatronId);
			query.setInt(1, patronId);
		
			result = query.executeQuery();
		
			while (result.next()) {
				itemId = result.getInt(1);
				copyNumber = result.getInt(2);
				title = result.getString(3);
				author = result.getString(4);
				timesRenewed = result.getInt(5);
				dueDate = result.getDate(6);
				java.util.Date dueUtilDate = (dueDate == null) ? null : new java.util.Date(dueDate.getTime());
			
				copy = new LoanedCopy(itemId, copyNumber, title, author, dueUtilDate, timesRenewed);
				copies.add(copy);
			}
			
			query.close();
			result.close();
			commit(connection);
		} catch (SQLException sql) {
			Trace.error(sql);
			try {
				rollback(connection);
			} catch (SQLException re) {
			}
			throw new SystemUnavailableException(sql);
		}		
		
		return copies;
	}
	
	/**
	 * @see com.ibm.ils.library.datastore.CopyDatastore#findCopiesForItem(int)
	 */
	public Collection<Copy> findCopiesForItemId(int itemId) throws ItemNotFound, SystemUnavailableException {
		Copy copy = null;
		Connection connection = null;
		ResultSet result = null;
		int copyNumber = 0;
		String loanable = null;
		boolean isLoanable = false;
		int timesRenewed = 0;
		Date dueDate = null;

		List<Copy> copies = new ArrayList<Copy>();
		
		try {
			connection = getConnection();
			PreparedStatement query = connection.prepareStatement(findCopiesForItemId);
			query.setInt(1, itemId);
		
			result = query.executeQuery();
		
			while (result.next()) {
				itemId = result.getInt(1);
				copyNumber = result.getInt(2);
				loanable = result.getString(3);
				timesRenewed = result.getInt(4);
				if (result.wasNull()) {
					timesRenewed = 0;
				}
				dueDate = result.getDate(5);
				if (result.wasNull()) {
					dueDate = null;
				}
				java.util.Date dueUtilDate = (dueDate == null) ? null : new java.util.Date(dueDate.getTime());
			
				if (loanable.toUpperCase().equals("T")) {
					isLoanable = true;
				} else {
					isLoanable = false;
				}
				copy = new Copy(itemId, copyNumber, isLoanable, dueUtilDate, timesRenewed);
				copies.add(copy);
			}
			
			query.close();
			result.close();
			commit(connection);
		} catch (SQLException sql) {
			Trace.error(sql);
			try {
				rollback(connection);
			} catch (SQLException re) {
			}
			throw new SystemUnavailableException(sql);
		}		
		
		return copies;
	}

	
	public void renew(Copy copy, java.util.Date newDueDate) throws CopyNotFound, SystemUnavailableException {
		Connection connection = null;
		// we need to keep the old and new values for the
		//  update
		int timesRenewed = copy.getTimesRenewed();
		Date due = new Date(copy.getDue().getTime());
		int newTimesRenewed = timesRenewed+1;
		Date newDue = new Date(newDueDate.getTime());
		
		try {
			connection = getConnection();
	
			PreparedStatement update = connection.prepareStatement(updateRenew);
	
			// do the update
			try {
				update.setInt(1, newTimesRenewed);
				update.setDate(2, newDue);
				update.setInt(3, copy.getItemId());
				update.setInt(4, copy.getCopyNumber());
				update.setInt(5, timesRenewed);
				update.setDate(6, due);
				update.execute();
				int updatedRows = update.getUpdateCount();
				update.close();
				// throw an exception if there Patron does not exist
				if (updatedRows == 0) {
					rollback(connection);
					throw new CopyNotFound(copy.getItemId(), copy.getCopyNumber());
				}
				copy.setTimesRenewed(newTimesRenewed);
				copy.setDue(new java.util.Date(newDue.getTime()));
			} catch (SQLException sql) {
				boolean exists = false;
				
				if (sql.getSQLState().startsWith("23")) {
					exists = true;
				}
				// process the SQL exception here
				Trace.message("Update Copy failed", Trace.HIGH);
				Trace.message(sql.getMessage(), Trace.HIGH);
				rollback(connection);
				if (exists) {
					throw new SystemUnavailableException(sql);
				} else {
					throw new SystemUnavailableException(sql);
				}
			}
			
			commit(connection);
		} catch (SQLException sqlOuter) {
			throw new SystemUnavailableException(sqlOuter);
		}
	}
	
	/**
	 * Method getNextId.
	 * @return int
	 */
	private int getNextId(int itemId, Connection connection) throws SQLException {
		int maxId;
		PreparedStatement query = connection.prepareStatement(findMaxId);
		query.setInt(1, itemId);
		// get the result set
		ResultSet resultSet = query.executeQuery();
	
		// process the result set
		if (resultSet.next()) {
			maxId = resultSet.getInt(1);
			resultSet.close();
			query.close();
		} else {
			query.close();
			throw new SQLException("Cannot determine the new item key");
		}

		return maxId+1;
	}
	
	/**
	 * Gets the connection
	 * @return Returns a ConnectionFactory
	 */
	private Connection getConnection() throws SQLException {
		return getConnectionFactory().getConnection();
	}

	/**
	 * Returns the factory.
	 * @return ConnectionFactory
	 */
	public ConnectionFactory getConnectionFactory() {
		return factory;
	}

	/**
	 * Sets the factory.
	 * @param factory The factory to set
	 */
	public void setConnectionFactory(ConnectionFactory factory) {
		this.factory = factory;
	}
	
	private void commit(Connection connection) throws SQLException {
		try {
			connection.commit();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.err.println("connection.close() failed");
				e.printStackTrace(System.err);
			}
		}
	}
	
	private void rollback(Connection connection) throws SQLException {
		try {
			connection.rollback();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.err.println("connection.close() failed");
				e.printStackTrace(System.err);
			}
		}
	}
}
