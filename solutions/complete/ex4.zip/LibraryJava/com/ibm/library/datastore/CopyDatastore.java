package com.ibm.library.datastore;

import java.util.Collection;

import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.Copy;
import com.ibm.library.model.Item;
import com.ibm.library.model.Patron;
import com.ibm.library.model.exceptions.CopyExists;
import com.ibm.library.model.exceptions.CopyNotFound;
import com.ibm.library.model.exceptions.ItemNotFound;
import com.ibm.library.model.exceptions.PatronNotFound;

/**
 * @author vogeld
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public interface CopyDatastore {
	void add(Copy copy) throws CopyExists, ItemNotFound, SystemUnavailableException;
	void remove(Copy copy) throws CopyNotFound, ItemNotFound, SystemUnavailableException;
	void update(Copy copy) throws CopyNotFound, ItemNotFound, SystemUnavailableException;
	Collection findCopiesForPatronId(int patronid) throws SystemUnavailableException;
	Collection findCopiesForItemId(int itemId) throws ItemNotFound, SystemUnavailableException;
	Collection findLoanedCopiesForPatronId(int patronId) throws SystemUnavailableException;
	void renew(Copy copy, java.util.Date newDueDate) throws CopyNotFound, SystemUnavailableException;
	Item getItem(Copy copy) throws ItemNotFound, SystemUnavailableException;
	Patron getPatron(Copy copy) throws PatronNotFound, SystemUnavailableException;
}
