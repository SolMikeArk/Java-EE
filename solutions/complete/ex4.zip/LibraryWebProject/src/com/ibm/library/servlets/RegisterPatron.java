package com.ibm.library.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.library.datastore.exceptions.SystemUnavailableException;
import com.ibm.library.model.Patron;
import com.ibm.library.model.exceptions.InvalidPassword;
import com.ibm.library.model.exceptions.PatronExists;

/**
 * Servlet implementation class RegisterPatron
 */
@WebServlet("/Register")
public class RegisterPatron extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterPatron() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	private void processRequest(
			HttpServletRequest req,
			HttpServletResponse resp)
			throws IOException {

			Patron patron = null;

			// Build the Patron from the HttpServletRequest fields
			patron = buildPatron(req);

			// Verfify that the patron is valid. Build a message based
			// on the results of the processing.
			if (!(isValid(patron))) {
				// No, one or more fields are missing
				displayMissingFields(resp);
			} else {
				// Try to add the new patron
				try {
					patron.add();
					displayPatronAdded(patron, resp);
				} catch (PatronExists e) {
					displayDuplicatePatron(patron, resp);
				} catch (SystemUnavailableException e) {
					displaySystemError(resp, e);
				} catch (InvalidPassword e) {
					String message = e.getMessage();
					displayInvalidPassword(message, resp);
				}
			}
		}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	
	private Patron buildPatron(HttpServletRequest req) {
		   // pull off all of the fields and create a new Patron
		   Patron patron = null;
		   String firstName = req.getParameter("FIRST_NAME");
		   String lastName = req.getParameter("LAST_NAME");
		   String password = req.getParameter("PASSWORD");
		   String email = req.getParameter("EMAIL");
		   patron = new Patron(firstName, lastName, password, email);
		   return patron;
	}
	
	private boolean isValid(Patron patron) {
		String firstName = patron.getFirstName();
		String lastName = patron.getLastName();
		String email = patron.getEmail();

		boolean error = firstName == null || firstName.length() == 0
			|| lastName == null || lastName.length() == 0
			|| email == null || email.length() == 0;

		return !error;
	}
	
	private void displayMissingFields(HttpServletResponse resp) throws IOException {
		PrintWriter out = resp.getWriter();
		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<TITLE>Missing Fields</TITLE>");
		out.println("<LINK rel=\"stylesheet\" type=\"text/css\" href=\"/Library/theme/Master.css\">");
		out.println("</HEAD>");
		out.println("<P>");
		out.println("Registration failed: One or more fields are incomplete." +
			" Please fill in all fields and try again");
		out.println("</P>");
		out.println("</BODY>");
		out.println("</HTML>");
	}
	
	private void displayDuplicatePatron(Patron patron, HttpServletResponse resp)	throws IOException {
		PrintWriter out = resp.getWriter();
		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<TITLE>Duplicate Patron</TITLE>");
		out.println("<LINK rel=\"stylesheet\" type=\"text/css\" href=\"/Library/theme/Master.css\">");
		out.println("</HEAD>");
		out.println("<P>");
		out.println("Registration failed: Patron " + patron.getEmail() + 
			" already exists and could not be added");
		out.println("</P>");
		out.println("</BODY>");
		out.println("</HTML>");
	}
	
	private void displaySystemError(
			HttpServletResponse resp,
			SystemUnavailableException e)
			throws IOException {

			PrintWriter out = resp.getWriter();
			out.println("<HTML>");
			out.println("<HEAD>");
			out.println("<TITLE>System Error</TITLE>");
			out.println(
				"<LINK rel=\"stylesheet\" type=\"text/css\""
					+ " href=\"/Library/theme/Master.css\">");
			out.println("</HEAD>");
			out.println("<P>");
			out.println(
				"Registration failed: There is a system error. "
					+ "Please try the registration later");
			out.println("</P>");
			out.println("</BODY>");
			out.println("</HTML>");
	}
	
	private void displayInvalidPassword(
			String message,
			HttpServletResponse resp)
			throws IOException {

			PrintWriter out = resp.getWriter();
			out.println("<HTML>");
			out.println("<HEAD>");
			out.println("<TITLE>Invalid password</TITLE>");
			out.println(
				"<LINK rel=\"stylesheet\" type=\"text/css\""
					+ " href=\"/Library/theme/Master.css\">");
			out.println("</HEAD>");
			out.println("<P>");
			out.println(
				"Registration failed: " + "Patron could not be added. " + message);
			out.println("</P>");
			out.println("</BODY>");
			out.println("</HTML>");
	}

	private void displayPatronAdded(Patron patron, HttpServletResponse resp)
			throws IOException {
			PrintWriter out = resp.getWriter();
			out.println("<HTML>");
			out.println("<HEAD>");
			out.println("<TITLE>Patron Added</TITLE>");
			out.println(
				"<LINK rel=\"stylesheet\" type=\"text/css\""
					+ " href=\"/Library/theme/Master.css\">");
			out.println("</HEAD>");
			out.println("<P>");
			out.println(
				"Patron "
					+ patron.getEmail()
					+ " with id "
					+ patron.getId()
					+ " has been added.");
			out.println("</P>");
			out.println("</BODY>");
			out.println("</HTML>");
	}

}
